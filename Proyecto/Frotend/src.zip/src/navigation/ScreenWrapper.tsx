import React from "react";
import { View, StyleSheet } from "react-native";

export default function ScreenWrapper({ children }: any) {
  return <View style={styles.wrapper}>{children}</View>;
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    paddingTop: 90, // 🔥 espacio fijo para tu Header
  },
});
