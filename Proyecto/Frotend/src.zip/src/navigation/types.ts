export type RootStackParamList = {
  Login: undefined;
  Registro: undefined;

  Menu: undefined;

  // Pantallas con parÃ¡metros
  DetallesProducto: { producto: any };

  // Probador debe recibir id_producto
  Probador: { id_producto: number | null };

  // Formularios
  FormularioProducto: undefined;
  FormularioEmpleado: undefined;
  FormularioDireccion: undefined;
};