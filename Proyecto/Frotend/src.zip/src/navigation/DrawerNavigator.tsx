// src/navigation/DrawerNavigator.tsx
import React, { useEffect, useState } from "react";
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItem,
} from "@react-navigation/drawer";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { View } from "react-native";

import Inicio from "../pantallas/inicio";
import Probador from "../pantallas/probador";
import Perfil from "../pantallas/perfil";
import Carrito from "../pantallas/carrito";
import Galeria from "../pantallas/galeria";

import DetallesProducto from "../pantallas/detallesProducto";
import FormularioProducto from "../pantallas/FormularioProducto";
import FormularioEmpleado from "../pantallas/FormularioEmpleados";
import FormularioDireccion from "../pantallas/FormularioDireccion";
import ProductManagerScreen from "../pantallas/ProductManagerScreen";
import GestionEmpleados from "../pantallas/GestionEmpleados";

import Header from "../components/Header";

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props: any) {
  const [rol, setRol] = useState<string | null>(null);

  useEffect(() => {
    const cargarRol = async () => {
      const raw = await AsyncStorage.getItem("user");
      if (raw) {
        const user = JSON.parse(raw);
        setRol(user.rol);
      }
    };
    cargarRol();
  }, []);

  const nav = props.navigation;

  return (
    <DrawerContentScrollView {...props}>
      <DrawerItem label="Inicio" onPress={() => nav.navigate("Inicio")} />
      <DrawerItem label="Probador" onPress={() => nav.navigate("Probador")} />
      <DrawerItem label="Perfil" onPress={() => nav.navigate("Perfil")} />
      <DrawerItem label="Carrito" onPress={() => nav.navigate("Carrito")} />
      <DrawerItem label="Galeria" onPress={() => nav.navigate("Galeria")} />

      {(rol === "ADMIN" || rol === "EMPLEADO") && (
        <DrawerItem
          label="Gestion de Productos"
          onPress={() => nav.navigate("Gestion de Productos")}
        />
      )}

      {rol === "ADMIN" && (
        <DrawerItem
          label="Gestionar Empleados"
          onPress={() => nav.navigate("Gestionar Empleados")}
        />
      )}

      <View style={{ marginTop: 20 }}>
        <DrawerItem
          label="Cerrar sesion"
          onPress={() => nav.navigate("Login")}
          labelStyle={{ color: "#E53935", fontWeight: "bold" }}
        />
      </View>
    </DrawerContentScrollView>
  );
}

export default function DrawerNavigator() {
  return (
    <Drawer.Navigator
      initialRouteName="Inicio"
      drawerContent={(props) => <CustomDrawerContent {...props} />}

      screenOptions={{
        header: () => <Header />, // nuestro header
        headerShown: true,        // IMPORTANTÍSIMO!!!
      }}
    >
      <Drawer.Screen name="Inicio" component={Inicio} />
      <Drawer.Screen name="Probador" component={Probador} />
      <Drawer.Screen name="Perfil" component={Perfil} />
      <Drawer.Screen name="Carrito" component={Carrito} />
      <Drawer.Screen name="Galeria" component={Galeria} />
      <Drawer.Screen name="DetallesProducto" component={DetallesProducto} options={{ drawerItemStyle: { display: "none" } }} />
      <Drawer.Screen name="FormularioProducto" component={FormularioProducto} options={{ drawerItemStyle: { display: "none" } }} />
      <Drawer.Screen name="FormularioEmpleado" component={FormularioEmpleado} options={{ drawerItemStyle: { display: "none" } }} />
      <Drawer.Screen name="FormularioDireccion" component={FormularioDireccion} options={{ drawerItemStyle: { display: "none" } }} />
      <Drawer.Screen name="Gestion de Productos" component={ProductManagerScreen} options={{ drawerItemStyle: { display: "none" } }} />
      <Drawer.Screen name="Gestionar Empleados" component={GestionEmpleados} options={{ drawerItemStyle: { display: "none" } }} />
    </Drawer.Navigator>
  );
}