// src/navigation/AppNavigator.tsx
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import Login from "../pantallas/login";
import Registro from "../pantallas/registro";
import DrawerNavigator from "./DrawerNavigator";

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  return (
    <Stack.Navigator initialRouteName="Login">

      {/* Login sin Header */}
      <Stack.Screen
        name="Login"
        component={Login}
        options={{ headerShown: false }}
      />

      {/* Registro sin Header */}
      <Stack.Screen
        name="Registro"
        component={Registro}
        options={{ headerShown: false }}
      />

      {/* Drawer completamente controlado por nosotros */}
      <Stack.Screen
        name="Menu"
        component={DrawerNavigator}
        options={{ headerShown: false }}
      />

    </Stack.Navigator>
  );
}