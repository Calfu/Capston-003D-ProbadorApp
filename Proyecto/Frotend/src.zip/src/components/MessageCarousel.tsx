import React, { useEffect, useRef, useState } from "react";
import { Animated, Text, View, StyleSheet, Easing } from "react-native";

const messages = [
  "Todos nuestros productos son 100% algodón ⭐",
  "Envíos a todo Chile 🚚",
  "Nuevas prendas cada semana 👕",
  "Combina cualquier prenda en nuestro Probador Virtual 🤳",
];

export default function MessageCarousel() {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [index, setIndex] = useState(0);

  const animateMessage = () => {
    Animated.sequence([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        easing: Easing.ease,
        useNativeDriver: true,
      }),
      Animated.delay(2000),
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 600,
        easing: Easing.ease,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setIndex((prev) => (prev + 1) % messages.length);
    });
  };

  useEffect(() => {
    animateMessage();
  }, [index]);

  return (
    <View style={styles.container}>
      <Animated.Text style={[styles.message, { opacity: fadeAnim }]}>
        {messages[index]}
      </Animated.Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    paddingVertical: 10,
    backgroundColor: "#1E4E77",
    alignItems: "center",
  },
  message: {
    color: "#e6fff0ff",
    fontSize: 16,
    fontWeight: "500",
  },
});