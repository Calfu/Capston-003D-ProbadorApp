// components/ChatBubble.tsx
import React, { useState, useRef, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Animated,
} from "react-native";
import { useTheme } from "../theme/ThemeContext";
import { API_BASE } from "../config";

export default function ChatBubble() {
  const { theme } = useTheme();

  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<
    { sender: "user" | "bot"; text: string }[]
  >([]);

  const [input, setInput] = useState("");

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scrollRef = useRef<ScrollView>(null);

  // ⭐ NUEVO — Estado para animación “escribiendo…”
  const [isTyping, setIsTyping] = useState(false);
  const typingOpacity = useRef(new Animated.Value(0)).current;

  // ⭐ Animación del texto “escribiendo…”
  useEffect(() => {
    if (isTyping) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(typingOpacity, {
            toValue: 1,
            duration: 600,
            useNativeDriver: true,
          }),
          Animated.timing(typingOpacity, {
            toValue: 0.3,
            duration: 600,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      typingOpacity.setValue(0);
    }
  }, [isTyping]);

  // ⭐ FORZAR QUE EL CHAT SIEMPRE INICIE CERRADO
  useEffect(() => {
    setOpen(false);
  }, []);

  // ⭐ Mensaje inicial al abrir
  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([
        {
          sender: "bot",
          text: "¡Hola! Soy Vesty 👗✨ ¿En qué puedo ayudarte hoy?",
        },
      ]);

      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 250,
        useNativeDriver: true,
      }).start();
    }
  }, [open]);

  // ⭐ Autoscroll
  useEffect(() => {
    scrollRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  // ⭐ Reset al cerrar chat
  const closeChat = () => {
    setOpen(false);
    setMessages([]);
    setInput("");
    setIsTyping(false);
  };

  // ⭐ Enviar mensaje al backend
  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMsg = input.trim();

    setMessages((prev) => [...prev, { sender: "user", text: userMsg }]);
    setInput("");

    // 🔵 ACTIVA animación “escribiendo…”
    setIsTyping(true);

    try {
      const res = await fetch(`${API_BASE}api/assistant`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg }),
      });

      const data = await res.json();
      const botReply = data.reply ?? "Lo siento, algo salió mal 😞";

      // 🟢 DESACTIVA animación
      setIsTyping(false);

      setMessages((prev) => [...prev, { sender: "bot", text: botReply }]);
    } catch (error) {
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: "Ups... no pude conectar con el servidor 😕" },
      ]);
    }
  };

  return (
    <>
      {/* ⭐ BOTÓN FLOTANTE */}
      {!open && (
        <TouchableOpacity
          style={[
            styles.floatingButton,
            { backgroundColor: theme.colors.primary },
          ]}
          onPress={() => setOpen(true)}
        >
          <Text style={styles.icon}>💬</Text>
        </TouchableOpacity>
      )}

      {/* ⭐ PANEL DEL CHAT */}
      {open && (
        <Animated.View
          style={[
            styles.chatContainer,
            { backgroundColor: theme.colors.cardBackground, opacity: fadeAnim },
          ]}
        >
          {/* Header */}
          <View
            style={[
              styles.chatHeader,
              { backgroundColor: theme.colors.primary },
            ]}
          >
            <Text style={styles.headerText}>Vesty • Asistente de moda</Text>

            <TouchableOpacity onPress={closeChat}>
              <Text style={styles.closeBtn}>✖</Text>
            </TouchableOpacity>
          </View>

          {/* Mensajes */}
          <ScrollView
            ref={scrollRef}
            style={styles.messagesArea}
            contentContainerStyle={{ paddingBottom: 20 }}
          >
            {messages.map((msg, idx) => (
              <View
                key={idx}
                style={[
                  styles.msgBubble,
                  msg.sender === "user"
                    ? {
                        alignSelf: "flex-end",
                        backgroundColor: theme.colors.primary,
                      }
                    : {
                        alignSelf: "flex-start",
                        backgroundColor: theme.colors.border,
                      },
                ]}
              >
                <Text
                  style={{
                    color: msg.sender === "user" ? "#FFF" : theme.colors.text,
                  }}
                >
                  {msg.text}
                </Text>
              </View>
            ))}

            {/* ⭐ NUEVO — Animación “El asistente está escribiendo…” */}
            {isTyping && (
              <Animated.View
                style={[styles.typingBox, { opacity: typingOpacity }]}
              >
                <Text style={styles.typingText}>
                  El asistente está escribiendo…
                </Text>
              </Animated.View>
            )}
          </ScrollView>

          {/* Input */}
          <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : undefined}
          >
            <View
              style={[
                styles.inputRow,
                {
                  borderColor: theme.colors.border,
                  backgroundColor: theme.colors.cardBackground,
                },
              ]}
            >
              <TextInput
                style={[styles.input, { color: theme.colors.text }]}
                placeholder="Escribe un mensaje..."
                placeholderTextColor={theme.colors.placeholder}
                value={input}
                onChangeText={setInput}
              />

              <TouchableOpacity style={styles.sendBtn} onPress={sendMessage}>
                <Text style={{ color: "#FFF", fontWeight: "700" }}>
                  Enviar
                </Text>
              </TouchableOpacity>
            </View>
          </KeyboardAvoidingView>
        </Animated.View>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  floatingButton: {
    position: "absolute",
    bottom: 35,
    right: 25,
    width: 65,
    height: 65,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 20,
    elevation: 8,
  },

  icon: { fontSize: 32, color: "white" },

  chatContainer: {
    position: "absolute",
    bottom: 100,
    right: 20,
    width: 300,
    height: 420,
    borderRadius: 15,
    overflow: "hidden",
    zIndex: 50,
    elevation: 10,
  },

  chatHeader: {
    height: 55,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  headerText: { color: "#FFF", fontSize: 16, fontWeight: "700" },

  closeBtn: { color: "#FFF", fontSize: 22 },

  messagesArea: { padding: 10, flexGrow: 1 },

  msgBubble: {
    maxWidth: "80%",
    padding: 10,
    marginVertical: 6,
    borderRadius: 12,
  },

  // ⭐ NUEVO — Estilos de animación escribiendo
  typingBox: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: "#dcdcdc",
    alignSelf: "flex-start",
    borderRadius: 12,
    marginLeft: 10,
    marginTop: 6,
  },
  typingText: {
    color: "#555",
    fontSize: 14,
    fontStyle: "italic",
  },

  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    borderTopWidth: 1,
    padding: 8,
  },

  input: { flex: 1, fontSize: 15, paddingHorizontal: 8 },

  sendBtn: {
    marginLeft: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: "#2F6DB5",
    borderRadius: 8,
  },
});