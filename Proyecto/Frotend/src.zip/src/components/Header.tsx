import React from "react";
import { View, StyleSheet, TouchableOpacity, Image, Text, Switch } from "react-native";
import { useNavigation, DrawerActions } from "@react-navigation/native";
import { useTheme } from "../theme/ThemeContext";
import { useFonts, PlayfairDisplay_700Bold } from "@expo-google-fonts/playfair-display";

type HeaderProps = {
  showMenu?: boolean;
};

export default function Header({ showMenu = true }: HeaderProps) {
  const navigation = useNavigation<any>();
  const { theme, toggleTheme } = useTheme();

  const [fontsLoaded] = useFonts({
    PlayfairDisplay_700Bold,
  });

  if (!fontsLoaded) return null;

  return (
    <View style={[styles.header, { backgroundColor: theme.colors.primary }]}>


      {/* Zona izquierda: Menú */}
      <View style={styles.left}>
        {showMenu && (
          <TouchableOpacity
            onPress={() => navigation.dispatch(DrawerActions.toggleDrawer())}
            style={styles.menuButton}
          >
            <Text style={[styles.menuText, { color: "#FFFFFF" }]}>☰</Text>
          </TouchableOpacity>
        )}
      </View>


      {/* Zona central: Logo */}
      <View style={styles.center}>
        <Image
          source={require("../../assets/logo_header.png")}
          style={styles.logoImage}
          resizeMode="contain"
        />
      </View>


      {/* Zona derecha: Switch */}
      <View style={styles.right}>
        <Switch
          value={theme.name === "dark"}
          onValueChange={toggleTheme}
          thumbColor="#FFFFFF"
          trackColor={{ false: "#888888", true: "#2F6DB5" }}
        />
      </View>


    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    width: "100%",
    height: 90,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 15,
  },

  left: {
    width: 60,
    justifyContent: "center",
    alignItems: "flex-start",
  },

  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  right: {
    width: 60,
    justifyContent: "center",
    alignItems: "flex-end",
  },

  menuButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },

  menuText: {
    fontSize: 28,
    fontWeight: "bold",
  },

  logoImage: {
    width: 150,
    height: 60,
  },
});