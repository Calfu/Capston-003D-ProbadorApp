declare module "react-native-vector-icons/Ionicons" {
  import { Icon } from "react-native-vector-icons/Icon";
  export default Icon;
}

declare module "react-native-vector-icons/MaterialIcons" {
  import { Icon } from "react-native-vector-icons/Icon";
  export default Icon;
}

declare module "react-native-vector-icons/FontAwesome" {
  import { Icon } from "react-native-vector-icons/Icon";
  export default Icon;
}