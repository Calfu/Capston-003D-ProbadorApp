import { Platform } from "react-native";
import Constants from "expo-constants";

// Intenta obtener la IP del host (Expo Go la expone en manifest)
function getLocalHost() {
  try {
    const manifest = Constants.expoConfig;
    const hostUri = manifest?.hostUri;

    if (hostUri) {
      // hostUri ejemplo: "192.168.1.12:19000"
      const ip = hostUri.split(":")[0];
      return ip;
    }
  } catch (e) {
    console.log("No se pudo leer hostUri:", e);
  }

  return null;
}

let API_BASE = "";

// WEB → usa localhost
if (Platform.OS === "web") {
  API_BASE = "http://localhost:8000/";
}
// ANDROID / IOS real → detecta automáticamente la IP LAN
else {
  const detectedIP = getLocalHost() ?? "localhost";
  API_BASE = `http://${detectedIP}:8000/`;
}

console.log("🌐 API_BASE configurada:", API_BASE);

export { API_BASE };