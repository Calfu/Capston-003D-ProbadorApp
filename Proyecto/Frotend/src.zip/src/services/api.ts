// src/services/api.ts
import { Platform } from "react-native";

// Base dinámica según la plataforma
const API_BASE =
  Platform.select({
    android: "http://10.0.2.2:8000/", // Emulador Android → localhost del PC
    ios: "http://127.0.0.1:8000/",
    default: "http://127.0.0.1:8000/",
  })!;

/**
 * Envía las imágenes al backend FastAPI (endpoint /tryon)
 */
export async function postTryOn(formData: FormData) {
  const resp = await fetch(`${API_BASE}tryon`, {
    method: "POST",
    body: formData,
  });

  if (!resp.ok) {
    throw new Error(`Error ${resp.status}: ${resp.statusText}`);
  }

  return await resp.json();
}

export default {
  postTryOn,
};