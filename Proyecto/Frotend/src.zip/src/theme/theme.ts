export const lightTheme = {
  name: "light",
  colors: {
    // 🎨 Paleta profesional clara
    primary: "#1F4E79", // Azul marino profesional
    background: "#F5F6FA", // Gris muy claro (tipo dashboard corporativo)
    text: "#1A1A1A", // Negro suave, legible
    inputBackground: "#E8ECF1", // Gris claro elegante
    inputText: "#2A2A2A",
    buttonBackground: "#2F6DB5", // Azul corporativo moderno
    buttonText: "#FFFFFF",

    // Tarjetas, listas, paneles
    cardBackground: "#FFFFFF", // Blanco limpio para tarjetas
    border: "#D0D4DB", // Borde gris claro profesional
    placeholder: "#8A8F99", // Gris suave para texto secundario

    // Tipografía
    headingColor: "#141821", // Títulos
    subtext: "#6A6F7A", // Textos informativos
  },
};

export const darkTheme = {
  name: "dark",
  colors: {
    // 🎨 Paleta profesional oscura
    primary: "#4C8BD9", // Azul acero (elegante y moderno)
    background: "#1B1D22", // Gris carbón profesional
    text: "#E6E6E6", // Gris muy claro, legible
    inputBackground: "#2A2D33", // Fondo de input oscuro moderno
    inputText: "#F0F0F0",
    buttonBackground: "#3E5C89", // Azul oscuro suave
    buttonText: "#FFFFFF",

    // Tarjetas y bordes
    cardBackground: "#26292F", // Gris grafito elegante
    border: "#3D4046", // Borde sutil
    placeholder: "#A7A9AD", // Gris claro para texto secundario

    // Tipografía
    headingColor: "#FFFFFF",
    subtext: "#9CA0A8",
  },
};

export type Theme = typeof lightTheme;
