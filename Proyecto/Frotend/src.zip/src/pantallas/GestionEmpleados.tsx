// src/pantallas/GestionEmpleados.tsx
import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useTheme } from "../theme/ThemeContext";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { API_BASE } from "../config";

export default function GestionEmpleados() {
  const { theme } = useTheme();
  const navigation: any = useNavigation();

  const [empleados, setEmpleados] = useState([]);

  // ================================
  // 🔐 Verificar que el usuario es ADMIN
  // ================================
  useEffect(() => {
    (async () => {
      const rol = await AsyncStorage.getItem("userRol");
      if (rol !== "ADMIN") {
        Alert.alert("Acceso denegado", "Solo administradores pueden gestionar empleados.");
        navigation.replace("Inicio");
      }
    })();
  }, []);

  // ================================
  // 📌 Cargar empleados desde BD
  // ================================
  const cargarEmpleados = async () => {
    try {
      const res = await fetch(`${API_BASE}empleados/listar`);
      const data = await res.json();
      setEmpleados(data);
    } catch (e) {
      console.log("Error cargando empleados:", e);
    }
  };

  // ================================
  // 🔁 Actualizar en tiempo real
  // ================================
  useFocusEffect(
    useCallback(() => {
      cargarEmpleados();
    }, [])
  );

  // ================================
  // 🗑 Eliminar empleado
  // ================================
  const eliminarEmpleado = (empleado: any) => {
    Alert.alert(
      "Confirmar eliminación",
      `¿Seguro que quieres eliminar al empleado ${empleado.nombre}?`,
      [
        { text: "No", style: "cancel" },
        {
          text: "Si",
          style: "destructive",
          onPress: async () => {
            try {
              await fetch(`${API_BASE}/empleados/${empleado.id_usuario}`, {
                method: "DELETE",
              });

              cargarEmpleados();
              Alert.alert("Eliminado", "Empleado eliminado correctamente.");
            } catch (e) {
              Alert.alert("Error", "No se pudo eliminar el empleado.");
            }
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          Gestión de Empleados
        </Text>

        {/* ➕ Botón “Añadir empleado” */}
        <TouchableOpacity
          style={[styles.btn, { backgroundColor: theme.colors.primary }]}
          onPress={() =>
            navigation.navigate("FormularioEmpleado", { modo: "crear" })
          }
        >
          <Text style={styles.btnText}>Añadir empleado</Text>
        </TouchableOpacity>

        {/* 📌 Lista de empleados */}
        <FlatList
          data={empleados}
          keyExtractor={(item: any) => item.id_usuario.toString()}
          renderItem={({ item }) => (
            <View
              style={[
                styles.card,
                {
                  backgroundColor:
                    theme.name === "light" ? "#F5F5F5" : "#2C2C2C",
                },
              ]}
            >
              <View style={{ flex: 1 }}>
                <Text style={[styles.cardName, { color: theme.colors.text }]}>
                  {item.nombre}
                </Text>
                <Text style={{ color: theme.colors.text }}>
                  {item.correo}
                </Text>
              </View>

              <View style={styles.actions}>
                {/* EDITAR */}
                <TouchableOpacity
                  style={[styles.actionBtn, { backgroundColor: "#4CAF50" }]}
                  onPress={() =>
                    navigation.navigate("FormularioEmpleado", {
                      modo: "editar",
                      empleado: item,
                    })
                  }
                >
                  <Text style={{ color: "#FFF" }}>Editar</Text>
                </TouchableOpacity>

                {/* ELIMINAR */}
                <TouchableOpacity
                  style={[styles.actionBtn, { backgroundColor: "#E53935" }]}
                  onPress={() => eliminarEmpleado(item)}
                >
                  <Text style={{ color: "#FFF" }}>Eliminar</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          ListEmptyComponent={
            <Text
              style={{
                color: theme.colors.text,
                textAlign: "center",
                marginTop: 20,
              }}
            >
              No hay empleados registrados.
            </Text>
          }
          contentContainerStyle={{ paddingBottom: 30 }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, padding: 20, paddingTop: 90 },
  title: { fontSize: 24, fontWeight: "700", marginBottom: 20, textAlign: "center" },
  btn: { paddingVertical: 14, borderRadius: 10, alignItems: "center", marginBottom: 20 },
  btnText: { fontWeight: "700", color: "#FFF", fontSize: 16 },
  card: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
  },
  cardName: { fontSize: 16, fontWeight: "700" },
  actions: { flexDirection: "row", gap: 10 },
  actionBtn: { paddingVertical: 6, paddingHorizontal: 10, borderRadius: 8 },
});