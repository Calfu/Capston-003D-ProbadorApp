import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  Modal,
  TouchableWithoutFeedback,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useTheme } from "../theme/ThemeContext";
import { API_BASE } from "../config";

export default function Galeria() {
  const { theme } = useTheme();

  const [imagenes, setImagenes] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const [modalVisible, setModalVisible] = useState(false);
  const [indexSeleccionado, setIndexSeleccionado] = useState(0);

  useEffect(() => {
    (async () => {
      try {
        const userId = await AsyncStorage.getItem("userId");
        if (!userId) return;

        const res = await fetch(`${API_BASE}tryon/listar/${userId}`);
        const data = await res.json();

        if (data.ok) {
          const base = API_BASE.endsWith("/") ? API_BASE : API_BASE + "/";
          const lista = (data.imagenes || []).map((img: string) => {
            const clean = img.startsWith("/") ? img.slice(1) : img;
            return base + clean;
          });

          setImagenes(lista);
        }
      } catch (err) {
        console.log("Error cargando galería:", err);
      }

      setLoading(false);
    })();
  }, []);

  const clearGallery = async () => {
    try {
      const userId = await AsyncStorage.getItem("userId");
      if (!userId) return;

      await fetch(`${API_BASE}tryon/borrar/${userId}`, { method: "DELETE" });

      setImagenes([]);
    } catch (err) {
      console.log("Error borrando galería:", err);
    }
  };

  const abrirImagen = (index: number) => {
    setIndexSeleccionado(index);
    setModalVisible(true);
  };

  const imagenAnterior = () => {
    setIndexSeleccionado((prev) =>
      prev === 0 ? imagenes.length - 1 : prev - 1
    );
  };

  const imagenSiguiente = () => {
    setIndexSeleccionado((prev) =>
      prev === imagenes.length - 1 ? 0 : prev + 1
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={[styles.title, { color: theme.colors.text }]}>Galería</Text>

        {loading ? (
          <Text style={[styles.emptyText, { color: theme.colors.text }]}>Cargando...</Text>
        ) : imagenes.length === 0 ? (
          <Text style={[styles.emptyText, { color: theme.colors.text }]}>No tienes imágenes generadas.</Text>
        ) : (
          <View style={styles.grid}>
            {imagenes.map((uri, index) => (
              <TouchableOpacity key={index} onPress={() => abrirImagen(index)}>
                <View style={styles.thumbContainer}>
                  <Image source={{ uri }} style={styles.thumb} />
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {imagenes.length > 0 && (
          <TouchableOpacity
            style={[styles.btnClear, { backgroundColor: theme.colors.buttonBackground }]}
            onPress={clearGallery}
          >
            <Text style={[styles.btnText, { color: theme.colors.buttonText }]}>Borrar galería</Text>
          </TouchableOpacity>
        )}
      </ScrollView>

      <Modal visible={modalVisible} transparent animationType="fade">
        <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
          <View style={styles.modalBackground}>
            <TouchableWithoutFeedback>
              <View style={styles.modalContent}>
                <Image source={{ uri: imagenes[indexSeleccionado] }} style={styles.fullImage} />

                <View style={styles.navRow}>
                  <TouchableOpacity style={styles.navButton} onPress={imagenAnterior}>
                    <Text style={styles.navText}>{"<"}</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={styles.navButton} onPress={imagenSiguiente}>
                    <Text style={styles.navText}>{">"}</Text>
                  </TouchableOpacity>
                </View>

              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  scroll: {
    paddingTop: 100,
    paddingHorizontal: 16,
    paddingBottom: 30,
  },

  title: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 20,
    textAlign: "center",
  },

  emptyText: {
    fontSize: 16,
    textAlign: "center",
    marginTop: 40,
  },

  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  // 🔥 DEBUG VISUAL → Fuerza cajas ROJAS visibles
  thumbContainer: {
    width: 200,
    height: 200,
    backgroundColor: "red",
    marginBottom: 12,
    overflow: "hidden",
    borderRadius: 10,
  },

  thumb: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },

  btnClear: {
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 20,
  },

  btnText: { fontSize: 16, fontWeight: "600" },

  modalBackground: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.85)",
    justifyContent: "center",
    alignItems: "center",
  },

  modalContent: {
    width: "90%",
    alignItems: "center",
  },

  fullImage: {
    width: "100%",
    height: 400,
    resizeMode: "contain",
    borderRadius: 10,
    marginBottom: 20,
  },

  navRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "60%",
  },

  navButton: { padding: 10 },

  navText: { fontSize: 32, color: "white", fontWeight: "bold" },
});