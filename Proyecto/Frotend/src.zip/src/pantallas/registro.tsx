import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Platform,
  Image,
} from "react-native";
import { useNavigation, NavigationProp } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useTheme } from "../theme/ThemeContext";

import { API_BASE } from "../config";

type RootStackParamList = {
  Login: undefined;
  Registro: undefined;
  Menu: undefined;
};

const showAlert = (title: string, message: string) => {
  if (Platform.OS === "web") window.alert(`${title}\n\n${message}`);
  else Alert.alert(title, message);
};

export default function Registro() {
  const { theme } = useTheme();
  const navigation = useNavigation<NavigationProp<RootStackParamList>>();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    if (!name || !email || !password || !confirmPassword) {
      showAlert("Campos incompletos", "Por favor completa todos los campos.");
      return;
    }

    if (password !== confirmPassword) {
      showAlert("Error", "Las contraseñas no coinciden.");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}usuarios/registro`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nombre: name,
          correo: email,
          contrasena: password,
        }),
      });

      if (response.ok) {
        showAlert("Registro exitoso", "Tu cuenta ha sido creada correctamente.");
        navigation.navigate("Login");
      } else {
        const errorData = await response.json();
        showAlert("Error", errorData.detail || "No se pudo crear la cuenta.");
      }
    } catch (e) {
      console.error("Error en registro:", e);
      showAlert("Error", "Hubo un problema de conexión con el servidor.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>

      {/* LOGO CON FONDO */}
      <View
        style={[
          styles.logoBox,
          {
            backgroundColor:
              theme.name === "light" ? "rgba(0,0,0,0.1)" : "rgba(255,255,255,0.1)",
          },
        ]}
      >
        <Image
          source={require("../../assets/logo_header.png")}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>

      {/* MENSAJE */}
      <Text style={[styles.welcome, { color: theme.colors.text }]}>
        Bienvenido a la aplicación oficial de Probar & Vestir
      </Text>

      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.colors.text }]}>Crear Cuenta</Text>

        <TextInput
          style={[
            styles.input,
            { backgroundColor: theme.colors.inputBackground, color: theme.colors.inputText },
          ]}
          placeholder="Nombre completo"
          placeholderTextColor={theme.colors.inputText}
          value={name}
          onChangeText={setName}
        />

        <TextInput
          style={[
            styles.input,
            { backgroundColor: theme.colors.inputBackground, color: theme.colors.inputText },
          ]}
          placeholder="Correo electrónico"
          placeholderTextColor={theme.colors.inputText}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />

        <TextInput
          style={[
            styles.input,
            { backgroundColor: theme.colors.inputBackground, color: theme.colors.inputText },
          ]}
          placeholder="Contraseña"
          placeholderTextColor={theme.colors.inputText}
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <TextInput
          style={[
            styles.input,
            { backgroundColor: theme.colors.inputBackground, color: theme.colors.inputText },
          ]}
          placeholder="Confirmar contraseña"
          placeholderTextColor={theme.colors.inputText}
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          secureTextEntry
        />

        <TouchableOpacity
          style={[
            styles.btn,
            { backgroundColor: theme.colors.buttonBackground, opacity: loading ? 0.7 : 1 },
          ]}
          onPress={handleRegister}
          disabled={loading}
        >
          <Text style={[styles.btnText, { color: theme.colors.buttonText }]}>
            {loading ? "Creando cuenta..." : "Registrarme"}
          </Text>
        </TouchableOpacity>

        <Text
          style={[styles.link, { color: theme.colors.primary }]}
          onPress={() => navigation.navigate("Login")}
        >
          ¿Ya tienes cuenta? Inicia sesión
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center" },

  logoBox: {
    width: 180,
    height: 90,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 60,
    marginBottom: 15,
  },

  logo: { width: 130, height: 60 },

  welcome: {
    fontSize: 15,
    fontWeight: "500",
    marginBottom: 25,
    textAlign: "center",
    width: "80%",
  },

  content: { width: "85%" },

  title: {
    fontSize: 28,
    fontWeight: "700",
    marginBottom: 40,
    textAlign: "center",
  },

  input: { borderRadius: 8, padding: 12, marginBottom: 20 },

  btn: { padding: 14, borderRadius: 10 },

  btnText: {
    width: "90%",
    alignSelf: "center",
    textAlign: "center",
    fontWeight: "600",
    fontSize: 16,
  },

  link: { textAlign: "center", marginTop: 15 },
});