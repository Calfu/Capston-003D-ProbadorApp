import React, { useState, useEffect } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Image, Platform, Alert
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { Picker } from "@react-native-picker/picker";
import { useTheme } from "../theme/ThemeContext";

import { useNavigation, useRoute } from "@react-navigation/native";
import { API_BASE } from "../config";

// =========================
// Tipos
// =========================
interface ImagenProducto {
  id_imagen?: number;
  uri: string;
  es_portada?: "S" | "N";
  url_imagen?: string;
}

interface ProductoEditar {
  id_producto: number;
  nombre: string;
  descripcion: string;
  categoria: string;
  genero: string;
  precio: number;
  stock: number;
  tallas?: { id_talla: number }[];
  imagenes?: ImagenProducto[];
}

const showAlert = (title: string, message: string) => {
  if (Platform.OS === "web") window.alert(`${title}\n\n${message}`);
  else Alert.alert(title, message);
};

export default function FormularioProducto() {
  const { theme } = useTheme();
  const navigation = useNavigation();
  const route = useRoute<any>();
  const productoEditar: ProductoEditar | null = route.params?.producto || null;

  const [nombre, setNombre] = useState(productoEditar?.nombre || "");
  const [descripcion, setDescripcion] = useState(productoEditar?.descripcion || "");
  const [categoria, setCategoria] = useState<string>(productoEditar?.categoria || "");
  const [genero, setGenero] = useState<string>(productoEditar?.genero || "");
  const [precio, setPrecio] = useState(productoEditar?.precio?.toString() || "");
  const [stock, setStock] = useState(productoEditar?.stock?.toString() || "");

  // MULTI-TALLAS
  const [tallasSeleccionadas, setTallasSeleccionadas] = useState<number[]>([]);

  // IMAGENES
  const [imagenPortada, setImagenPortada] = useState<string | null>(null);
  const [imagenes, setImagenes] = useState<{ id?: number; uri: string }[]>([]);

  // Catálogos
  const [categorias, setCategorias] = useState<any[]>([]);
  const [generos, setGeneros] = useState<any[]>([]);
  const [tallas, setTallas] = useState<any[]>([]);
  const [modoEdicion] = useState(!!productoEditar);

  // =============================
  // CARGAR CATEGORÍAS, GÉNEROS Y TALLAS
  // =============================
  useEffect(() => {
    (async () => {
      try {
        const [catRes, genRes, tallaRes] = await Promise.all([
          fetch(`${API_BASE}productos/categorias`),
          fetch(`${API_BASE}productos/generos`),
          fetch(`${API_BASE}productos/tallas`),
        ]);
        setCategorias(await catRes.json());
        setGeneros(await genRes.json());
        setTallas(await tallaRes.json());
      } catch (e) {
        showAlert("Error", "No se pudieron cargar las opciones.");
      }
    })();
  }, []);

  // =============================
  // 🔥 PRECARGA DE DATOS EN EDICIÓN
  // =============================
  useEffect(() => {
    if (!productoEditar) return;

    // TALLAS
    if (productoEditar.tallas) {
      setTallasSeleccionadas(productoEditar.tallas.map((t: { id_talla: number }) => t.id_talla));
    }

    // PORTADA
    const portada = productoEditar.imagenes?.find(
      (img: ImagenProducto) => img.es_portada === "S"
    );

    if (portada && portada.url_imagen) {
      const safeBase = API_BASE.replace(/\/$/, "");
      const safePath = portada.url_imagen.replace(/^\//, "");
      setImagenPortada(`${safeBase}/${safePath}`);
    }

    // IMÁGENES EXTRA
    const extras = productoEditar.imagenes?.filter(
      (img: ImagenProducto) => img.es_portada === "N"
    );

    if (extras) {
      const safeBase = API_BASE.replace(/\/$/, "");

      setImagenes(
        extras.map((img: ImagenProducto) => ({
          id: img.id_imagen,
          uri: `${safeBase}/${(img.url_imagen ?? "").replace(/^\//, "")}`
        }))
      );
    }
  }, [productoEditar]);

  // =============================
  // SELECCIÓN DE TALLAS
  // =============================
  const toggleTalla = (id: number) => {
    setTallasSeleccionadas(prev =>
      prev.includes(id)
        ? prev.filter(t => t !== id)
        : [...prev, id]
    );
  };

  // =============================
  // SUBIR PORTADA
  // =============================
  const subirImagenPortada = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") return showAlert("Permiso denegado", "Necesitamos acceso a tu galería.");

    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });
    if (!res.canceled) {
      setImagenPortada(res.assets[0].uri);
    }
  };

  // =============================
  // SUBIR IMÁGENES EXTRA
  // =============================
  const subirImagenes = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") return;

    const res = await ImagePicker.launchImageLibraryAsync({
      allowsMultipleSelection: true,
      quality: 1,
    });
    if (!res.canceled) {
      const nuevas = res.assets.map(a => ({ uri: a.uri }));
      setImagenes(prev => [...prev, ...nuevas]);
    }
  };

  // =============================
  // 🗑️ ELIMINAR IMAGEN EXTRA
  // =============================
  const eliminarImagen = async (index: number) => {
    const img = imagenes[index];
    if (img.id) {
      await fetch(`${API_BASE}productos/eliminar-imagen/${img.id}`, { method: "DELETE" });
    }
    setImagenes(prev => prev.filter((_, i) => i !== index));
  };

  // =============================
  // 🗑️ ELIMINAR PORTADA
  // =============================
  const eliminarPortada = () => {
    setImagenPortada(null);
  };

  // =============================
  // VALIDAR
  // =============================
  const validarCampos = () => {
    if (!nombre.trim() || !descripcion.trim() || !precio || !stock)
      return showAlert("Error", "Completa todos los campos.");

    if (!categoria) return showAlert("Error", "Selecciona una categoría.");
    if (!genero) return showAlert("Error", "Selecciona un género.");
    if (tallasSeleccionadas.length === 0)
      return showAlert("Error", "Selecciona al menos una talla.");

    return true;
  };

  // =============================
  // GUARDAR
  // =============================
  const handleSubmit = async () => {
    if (!validarCampos()) return;

    try {
      const formData = new FormData();
      formData.append("nombre", nombre);
      formData.append("descripcion", descripcion);
      formData.append("categoria", categoria);
      formData.append("genero", genero);
      formData.append("precio", String(precio));
      formData.append("stock", String(stock));
      formData.append("tallas_ids", tallasSeleccionadas.join(","));

      // 🔹 Función para convertir base64 a Blob (solo web)
      const base64ToBlob = (base64Data: string, contentType: string) => {
        const byteCharacters = atob(base64Data.split(",")[1]);
        const byteArrays = [];
        for (let offset = 0; offset < byteCharacters.length; offset += 512) {
          const slice = byteCharacters.slice(offset, offset + 512);
          const byteNumbers = new Array(slice.length);
          for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
          }
          byteArrays.push(new Uint8Array(byteNumbers));
        }
        return new Blob(byteArrays, { type: contentType });
      };

      // ✅ PORTADA
      if (imagenPortada) {
        if (imagenPortada.startsWith("data:image")) {
          const blob = base64ToBlob(imagenPortada, "image/jpeg");
          formData.append("portada", blob, "portada.jpg");
        } else if (imagenPortada.startsWith("file")) {
          const filename = imagenPortada.split("/").pop() || "portada.jpg";
          formData.append("portada", {
            uri: imagenPortada,
            name: filename,
            type: "image/jpeg",
          } as any);
        }
      }

      // ✅ IMÁGENES EXTRA
      for (let i = 0; i < imagenes.length; i++) {
        const img = imagenes[i];
        if (img.uri.startsWith("data:image")) {
          const blob = base64ToBlob(img.uri, "image/jpeg");
          formData.append("imagenes", blob, `extra_${i}.jpg`);
        } else if (img.uri.startsWith("file")) {
          const filename = img.uri.split("/").pop() || `extra_${i}.jpg`;
          formData.append("imagenes", {
            uri: img.uri,
            name: filename,
            type: "image/jpeg",
          } as any);
        }
      }

      const url = modoEdicion
        ? `${API_BASE}productos/editar/${productoEditar?.id_producto}`
        : `${API_BASE}productos/crear`;

      const method = modoEdicion ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        body: formData,
        headers: {
          Accept: "application/json",
        },
      });

      const data = await res.json();
      console.log("Respuesta backend:", data);

      if (!res.ok) {
        return showAlert("Error", data.detail || "Error al guardar");
      }

      showAlert("Éxito", "Producto guardado correctamente.");
      navigation.goBack();
    } catch (e) {
      console.error("Error al guardar producto:", e);
      showAlert("Error", "No se pudo guardar el producto.");
    }
  };

  // =============================
  // RENDER
  // =============================
  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.colors.background }]}>

      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          {modoEdicion ? "Editar producto" : "Nuevo producto"}
        </Text>

        {/* NOMBRE */}
        <TextInput
          placeholder="Nombre"
          value={nombre}
          onChangeText={setNombre}
          style={[styles.input, { backgroundColor: theme.colors.inputBackground }]}
        />

        {/* DESCRIPCIÓN */}
        <TextInput
          placeholder="Descripción"
          value={descripcion}
          multiline
          onChangeText={setDescripcion}
          style={[styles.input, { height: 100 }]}
        />

        {/* CATEGORÍA */}
        <Text style={styles.label}>Categoría</Text>
        <Picker
          selectedValue={categoria}
          onValueChange={setCategoria}
          style={styles.picker}
        >
          <Picker.Item label="Seleccione..." value="" />
          {categorias.map((c: any) => (
            <Picker.Item key={c.id_categoria} label={c.nombre} value={c.nombre} />
          ))}
        </Picker>

        {/* GÉNERO */}
        <Text style={styles.label}>Género</Text>
        <Picker
          selectedValue={genero}
          onValueChange={setGenero}
          style={styles.picker}
        >
          <Picker.Item label="Seleccione..." value="" />
          {generos.map((g: any) => (
            <Picker.Item key={g.id_genero} label={g.nombre} value={g.nombre} />
          ))}
        </Picker>

        {/* TALLAS */}
        <Text style={styles.label}>Tallas</Text>
        {tallas.map((t: any) => (
          <TouchableOpacity
            key={t.id_talla}
            style={styles.checkboxRow}
            onPress={() => toggleTalla(t.id_talla)}
          >
            <View
              style={[
                styles.checkbox,
                tallasSeleccionadas.includes(t.id_talla) && styles.checkboxChecked,
              ]}
            />
            <Text>{t.codigo}</Text>
          </TouchableOpacity>
        ))}

        {/* PRECIO */}
        <TextInput
          placeholder="Precio"
          value={precio}
          keyboardType="numeric"
          onChangeText={setPrecio}
          style={styles.input}
        />

        {/* STOCK */}
        <TextInput
          placeholder="Stock"
          value={stock}
          keyboardType="numeric"
          onChangeText={setStock}
          style={styles.input}
        />

        {/* PORTADA */}
        <Text style={styles.label}>Portada</Text>
        {imagenPortada && (
          <View style={{ position: "relative" }}>
            <Image source={{ uri: imagenPortada }} style={styles.imagePreview} />
            <TouchableOpacity style={styles.deleteBtn} onPress={eliminarPortada}>
              <Text style={{ color: "white", fontWeight: "bold" }}>X</Text>
            </TouchableOpacity>
          </View>
        )}

        <TouchableOpacity style={styles.uploadBtn} onPress={subirImagenPortada}>
          <Text style={styles.uploadBtnText}>Subir portada</Text>
        </TouchableOpacity>

        {/* IMÁGENES EXTRA */}
        <Text style={styles.label}>Imágenes adicionales</Text>
        <ScrollView horizontal>
          {imagenes.map((img, i) => (
            <View key={i} style={{ position: "relative" }}>
              <Image source={{ uri: img.uri }} style={styles.imagePreview} />
              <TouchableOpacity style={styles.deleteBtn} onPress={() => eliminarImagen(i)}>
                <Text style={{ color: "white", fontWeight: "bold" }}>X</Text>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>

        <TouchableOpacity style={styles.uploadBtn} onPress={subirImagenes}>
          <Text style={styles.uploadBtnText}>Subir imágenes</Text>
        </TouchableOpacity>

        {/* BOTÓN */}
        <TouchableOpacity style={styles.btn} onPress={handleSubmit}>
          <Text style={styles.btnText}>
            {modoEdicion ? "Guardar cambios" : "Registrar producto"}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, padding: 20, paddingTop: 90 },
  title: { fontSize: 22, fontWeight: "700", marginBottom: 15 },
  input: { backgroundColor: "#EEE", padding: 12, borderRadius: 8, marginBottom: 10 },
  label: { fontSize: 16, fontWeight: "600", marginTop: 15, marginBottom: 6 },
  picker: { backgroundColor: "#EEE", borderRadius: 8, marginBottom: 10 },
  checkboxRow: { flexDirection: "row", alignItems: "center", marginBottom: 6 },
  checkbox: {
    width: 18, height: 18, borderRadius: 4, borderWidth: 1,
    borderColor: "#555", marginRight: 10,
  },
  checkboxChecked: { backgroundColor: "#4CAF50" },
  uploadBtn: { backgroundColor: "#6200EE", padding: 12, borderRadius: 10, alignItems: "center", marginVertical: 10 },
  uploadBtnText: { color: "#FFF", fontWeight: "600" },
  imagePreview: { width: 100, height: 100, borderRadius: 8, margin: 5 },
  deleteBtn: {
    position: "absolute", top: -8, right: -8,
    backgroundColor: "#E53935", width: 26, height: 26,
    borderRadius: 13, justifyContent: "center", alignItems: "center"
  },
  btn: { backgroundColor: "#6200EE", marginTop: 20, padding: 14, borderRadius: 10, alignItems: "center" },
  btnText: { color: "white", fontWeight: "700", fontSize: 16 },
});