// src/pantallas/ProductManagerScreen.tsx
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  Platform,
  Image,
} from "react-native";
import { useTheme } from "../theme/ThemeContext";

import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { API_BASE } from "../config";

const showAlert = (title: string, message: string) => {
  if (Platform.OS === "web") window.alert(`${title}\n\n${message}`);
  else Alert.alert(title, message);
};

// =============================
// Tipos de producto ampliados
// =============================
export type Producto = {
  id_producto: number;
  nombre: string;
  descripcion: string;
  categoria: string;
  genero: string;
  precio: number;
  stock: number;
  imagenes?: { id_imagen: number; url_imagen: string; es_portada: string }[];
  tallas?: { id_talla: number; talla: { codigo: string } }[];
};

export default function ProductManagerScreen() {
  const { theme } = useTheme();
  const navigation = useNavigation<any>();
  const [productos, setProductos] = useState<Producto[]>([]);
  const [rolUsuario, setRolUsuario] = useState<string | null>(null);

  // =============================
  // Verificar acceso
  // =============================
  useEffect(() => {
    const verificarAcceso = async () => {
      const raw = await AsyncStorage.getItem("user");
      const user = raw ? JSON.parse(raw) : null;

      if (!user) {
        showAlert("Error", "Debes iniciar sesión.");
        navigation.navigate("Login");
        return;
      }

      setRolUsuario(user.rol);

      if (user.rol !== "ADMIN" && user.rol !== "EMPLEADO") {
        showAlert("Acceso denegado", "No tienes permisos para esta pantalla.");
        navigation.navigate("Menu");
        return;
      }

      cargarProductos();
    };

    verificarAcceso();
  }, []);

  // =============================
  // Cargar productos
  // =============================
  const cargarProductos = async () => {
    try {
      const res = await fetch(`${API_BASE}productos/listar`);
      if (!res.ok) throw new Error("No se pudieron cargar los productos");
      const data: Producto[] = await res.json();
      setProductos(data);
    } catch (err) {
      console.error(err);
      showAlert("Error", "No se pudieron cargar los productos.");
    }
  };

  // =============================
  // Eliminar producto
  // =============================
  const eliminarProducto = async (id: number) => {
    const confirmar =
      Platform.OS === "web" ? window.confirm("¿Eliminar este producto?") : true;

    if (!confirmar) return;

    try {
      const res = await fetch(`${API_BASE}productos/eliminar/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Error");

      showAlert("Eliminado", "Producto eliminado correctamente.");
      setProductos((prev) => prev.filter((p) => p.id_producto !== id));
    } catch {
      showAlert("Error", "No se pudo eliminar el producto.");
    }
  };

  // =============================
  // Navegación
  // =============================
  const editarProducto = (producto: Producto) => {
    navigation.navigate("FormularioProducto", { producto });
  };

  const nuevoProducto = () => {
    navigation.navigate("FormularioProducto", undefined);
  };

  // =============================
  // Render de cada producto
  // =============================
  const renderItem = ({ item }: { item: Producto }) => {
    // Portada
    const portada = item.imagenes?.find((img) => img.es_portada === "S");
    const urlPortada = portada ? `${API_BASE}${portada.url_imagen}` : null;

    // Tallas (unidas por coma)
    const tallasTexto =
      item.tallas && item.tallas.length > 0
        ? item.tallas.map((t) => t.talla.codigo).join(", ")
        : "—";

    return (
      <View
        style={[styles.row, { backgroundColor: theme.colors.cardBackground }]}
      >
        {/* Imagen de portada */}
        {urlPortada && (
          <Image source={{ uri: urlPortada }} style={styles.portada} />
        )}

        <View style={{ flex: 1 }}>
          <Text style={[styles.nombre, { color: theme.colors.text }]}>
            #{item.id_producto} — {item.nombre}
          </Text>

          <Text style={[styles.descripcion, { color: theme.colors.text }]}>
            {item.descripcion}
          </Text>

          <Text style={[styles.info, { color: theme.colors.text }]}>
            {item.categoria} | {item.genero}
          </Text>

          <Text style={[styles.info, { color: theme.colors.text }]}>
            Tallas: {tallasTexto}
          </Text>

          <Text style={[styles.info, { color: theme.colors.text }]}>
            Stock: {item.stock} — ${item.precio}
          </Text>

          <View style={styles.actions}>
            <TouchableOpacity
              onPress={() => editarProducto(item)}
              style={[styles.actionBtn, { backgroundColor: "#2196F3" }]}
            >
              <Text style={{ color: "#fff" }}>Editar</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => eliminarProducto(item.id_producto)}
              style={[styles.actionBtn, { backgroundColor: "#E53935" }]}
            >
              <Text style={{ color: "#fff" }}>Eliminar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  // =============================
  // Render principal
  // =============================
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>


      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          Gestión de Productos
        </Text>

        <TouchableOpacity
          style={[
            styles.addButton,
            { backgroundColor: theme.colors.buttonBackground },
          ]}
          onPress={nuevoProducto}
        >
          <Text style={[styles.btnText, { color: theme.colors.buttonText }]}>
            + Añadir producto
          </Text>
        </TouchableOpacity>

        <FlatList
          data={productos}
          keyExtractor={(item) => item.id_producto.toString()}
          renderItem={renderItem}
          showsVerticalScrollIndicator={true}
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      </View>
    </View>
  );
}

// =============================
// Estilos
// =============================
const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, paddingTop: 90, paddingHorizontal: 10 },
  title: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 20,
    textAlign: "center",
  },
  row: {
    flexDirection: "row",
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    elevation: 2,
  },
  portada: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 10,
    backgroundColor: "#ddd",
  },
  nombre: { fontSize: 16, fontWeight: "700", marginBottom: 4 },
  descripcion: { fontSize: 13, marginBottom: 6 },
  info: { fontSize: 13, marginBottom: 3 },
  actions: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 6,
  },
  actionBtn: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
    marginLeft: 6,
  },
  addButton: {
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 15,
  },
  btnText: { fontSize: 16, fontWeight: "600" },
});