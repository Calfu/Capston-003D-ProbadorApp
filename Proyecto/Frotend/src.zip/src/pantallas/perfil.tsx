// src/pantallas/perfil.tsx
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
  Platform,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation, useRoute } from "@react-navigation/native";
import { useTheme } from "../theme/ThemeContext";
import DateTimePicker from "@react-native-community/datetimepicker";

export default function Perfil() {
  const { theme } = useTheme();
  const navigation = useNavigation<any>();
  const route = useRoute<any>();   // <-- 🔹 para recibir datos desde FormularioDireccion.tsx

  const [user, setUser] = useState<any>(null);

  const [profilePic, setProfilePic] = useState<string | null>(null);
  const [nombre, setNombre] = useState("");
  const [correo, setCorreo] = useState("");
  const [fecha_nac, setFechaNac] = useState<string | null>(null);
  const [edad, setEdad] = useState<number | null>(null);

  const [direccion, setDireccion] = useState<any>(null);
  const [showNativeDate, setShowNativeDate] = useState(false);

  const [changes, setChanges] = useState(false);

  // ========================================
  // CARGAR USUARIO DESDE ASYNCSTORAGE
  // ========================================
  useEffect(() => {
  (async () => {
    const raw = await AsyncStorage.getItem("user");
    if (!raw) return;

    const localUser = JSON.parse(raw);

    // 🔹 Pedir datos actualizados al backend
    const resp = await fetch(`http://localhost:8000/usuarios/${localUser.id_usuario}`);
    const fullUser = await resp.json();

    // 🔹 Guardar los datos actualizados en AsyncStorage
    await AsyncStorage.setItem("user", JSON.stringify(fullUser));

    // 🔹 Actualizar estados
    setUser(fullUser);
    setNombre(fullUser.nombre);
    setCorreo(fullUser.correo);

    if (fullUser.fecha_nac) {
      setFechaNac(fullUser.fecha_nac);
      calcularEdad(fullUser.fecha_nac);
    } else {
      setFechaNac(null);
    }

    setDireccion({
      calle: fullUser.calle,
      numero_casa: fullUser.numero_casa,
      ciudad: fullUser.ciudad,
      region: fullUser.region,
      pais: fullUser.pais,
      codigo_postal: fullUser.codigo_postal,
    });

    setProfilePic(fullUser.foto_perfil_url || null);
  })();
  }, []);

  // ========================================
  // RECIBIR DIRECCIÓN DESDE FormularioDireccion.tsx
  // ========================================
  useEffect(() => {
    if (route.params?.direccionActualizada) {
      setDireccion(route.params.direccionActualizada);
      setChanges(true); // habilita botón Guardar
    }
  }, [route.params?.direccionActualizada]);

  // ========================================
  // CALCULAR EDAD
  // ========================================
  const calcularEdad = (fecha: string) => {
    const birth = new Date(fecha);
    const now = new Date();

    let years = now.getFullYear() - birth.getFullYear();
    const m = now.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) years--;

    setEdad(years);
  };

  // ========================================
  // FOTO PERFIL
  // ========================================
  const pickProfilePicture = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });

    if (!res.canceled) {
      setProfilePic(res.assets[0].uri);
      setChanges(true);
    }
  };

  // ========================================
  // FECHA WEB
  // ========================================
  const handleWebDate = (value: string) => {
    setFechaNac(value);

    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      calcularEdad(value);
      setChanges(true);
    }
  };

  // ========================================
  // FECHA NATIVA
  // ========================================
  const onNativeDateChange = (event: any, date: Date | undefined) => {
    if (date) {
      const iso = date.toISOString().substring(0, 10);
      setFechaNac(iso);
      calcularEdad(iso);
      setChanges(true);
    }
    setShowNativeDate(false);
  };

  // ========================================
  // GUARDAR CAMBIOS
  // ========================================
  const guardarCambios = async () => {
    if (!user) return;

    const payload = {
      nombre,
      correo,
      fecha_nac,
      foto_perfil_url: profilePic,
      calle: direccion?.calle || null,
      numero_casa: direccion?.numero_casa || null,
      ciudad: direccion?.ciudad || null,
      region: direccion?.region || null,
      pais: direccion?.pais || null,
      codigo_postal: direccion?.codigo_postal || null,
    };

    try {
      // 1) Guardar cambios en el backend
      await fetch(`http://localhost:8000/usuarios/${user.id_usuario}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      // 2) Volver a consultar al backend los datos ACTUALIZADOS
      const resp = await fetch(`http://localhost:8000/usuarios/${user.id_usuario}`);
      const updatedUser = await resp.json();

      // 3) Guardar el usuario actualizado en AsyncStorage
      await AsyncStorage.setItem("user", JSON.stringify(updatedUser));

      // 4) Actualizar los estados locales
      setUser(updatedUser);
      setDireccion({
        calle: updatedUser.calle,
        numero_casa: updatedUser.numero_casa,
        ciudad: updatedUser.ciudad,
        region: updatedUser.region,
        pais: updatedUser.pais,
        codigo_postal: updatedUser.codigo_postal,
      });
      setProfilePic(updatedUser.foto_perfil_url);

      if (updatedUser.fecha_nac) {
        setFechaNac(updatedUser.fecha_nac);
        calcularEdad(updatedUser.fecha_nac);
    }

      alert("Cambios guardados.");
      setChanges(false);
    } catch (e) {
      alert("Error guardando cambios.");
    }
  };

  // ========================================
  // UI
  // ========================================
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>

      <View style={styles.content}>
        {/* FOTO PERFIL */}
        <TouchableOpacity onPress={pickProfilePicture}>
          <Image
            source={{
             uri: profilePic?.startsWith("data:")
                ? profilePic
                : `http://localhost:8000${profilePic}`
            }}
            style={styles.avatar}
          />
        </TouchableOpacity>

        {/* NOMBRE */}
        <TextInput
          style={[styles.input, { color: theme.colors.text }]}
          value={nombre}
          onChangeText={(t) => {
            setNombre(t);
            setChanges(true);
          }}
        />

        {/* CORREO */}
        <TextInput
          style={[styles.input, { color: theme.colors.text }]}
          value={correo}
          onChangeText={(t) => {
            setCorreo(t);
            setChanges(true);
          }}
        />

        {/* FECHA NAC */}
        {fecha_nac ? (
          <Text style={[styles.age, { color: theme.colors.text }]}>
            Edad: {edad} años
          </Text>
        ) : (
          <>
            {Platform.OS === "web" ? (
              <input
                type="date"
                value={fecha_nac ?? ""}
                style={styles.webInput as any}
                onChange={(e) => handleWebDate(e.target.value)}
              />
            ) : (
              <>
                <TouchableOpacity
                  style={styles.btn}
                  onPress={() => setShowNativeDate(true)}
                >
                  <Text style={{ color: "#FFF" }}>Seleccionar fecha</Text>
                </TouchableOpacity>

                {showNativeDate && (
                  <DateTimePicker
                    value={new Date()}
                    mode="date"
                    display="default"
                    onChange={onNativeDateChange}
                  />
                )}
              </>
            )}
          </>
        )}

        {/* DIRECCIÓN */}
        {direccion?.calle ? (
          <>
            <Text style={[styles.address, { color: theme.colors.text }]}>
              {direccion.calle}, {direccion.numero_casa}, {direccion.ciudad},{" "}
              {direccion.region}, {direccion.pais}
            </Text>

            <TouchableOpacity
              style={styles.btn}
              onPress={() =>
                navigation.navigate("FormularioDireccion", {
                  direccion: direccion,
                })
              }
            >
              <Text style={{ color: "#FFF" }}>Editar dirección</Text>
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity
            style={styles.btn}
            onPress={() => navigation.navigate("FormularioDireccion", { direccion: null })}
          >
            <Text style={{ color: "#FFF" }}>Registrar dirección</Text>
          </TouchableOpacity>
        )}

        {/* GUARDAR CAMBIOS */}
        {changes && (
          <TouchableOpacity style={styles.saveBtn} onPress={guardarCambios}>
            <Text style={styles.saveText}>Guardar cambios</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

// ===============================
// ESTILOS (sin cambios)
// ===============================
const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingTop: 100, paddingHorizontal: 20, alignItems: "center" },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 16,
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#AAA",
    borderRadius: 8,
    padding: 10,
    marginTop: 10,
  },
  webInput: {
    width: "100%",
    padding: 10,
    fontSize: 16,
    marginTop: 10,
  },
  age: { fontSize: 16, marginVertical: 10 },
  btn: {
    marginTop: 10,
    backgroundColor: "#5c75e4ff",
    padding: 10,
    borderRadius: 8,
  },
  address: {
    marginTop: 15,
    fontSize: 16,
    textAlign: "center",
  },
  saveBtn: {
    marginTop: 20,
    backgroundColor: "#5c75e4ff",
    padding: 12,
    borderRadius: 10,
    width: "100%",
  },
  saveText: {
    color: "#FFF",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "600",
  },
});