import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  FlatList,
  Animated,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation, NavigationProp } from "@react-navigation/native";
import { useTheme } from "../theme/ThemeContext";
import { useWindowDimensions } from "react-native";
import MessageCarousel from "../components/MessageCarousel";


import ChatBubble from "../components/ChatBubble";
import { API_BASE } from "../config";

type RootStackParamList = {
  DetallesProducto: { producto: any };
};

export default function Inicio() {
  const { theme } = useTheme();
  const navigation = useNavigation<NavigationProp<RootStackParamList>>();

  // ✔ SE USA HOOK AQUÍ (NO AFUERA)
  const { width } = useWindowDimensions();

  // ✔ COLUMNAS DINÁMICAS (RESPONSIVO)
  const columnCount = width < 500 ? 2 : width < 800 ? 3 : 4;

  const [productos, setProductos] = useState<any[]>([]);
  const [productosFiltrados, setProductosFiltrados] = useState<any[]>([]);
  const [carrusel, setCarrusel] = useState<any[]>([]);
  const [categorias, setCategorias] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  const scrollRef = useRef<ScrollView>(null);
  const animValue = useRef(new Animated.Value(0)).current;

  const cargarProductos = async () => {
    try {
      const res = await fetch(`${API_BASE}productos/listar`);
      const data = await res.json();

      const base = API_BASE.endsWith("/") ? API_BASE : API_BASE + "/";

      const productosConPortada = data.map((p: any) => {
        const portada = p.imagenes?.find((img: any) => img.es_portada === "S");

        let portada_url: string | null = null;

        if (portada && portada.url_imagen) {
          if (
            portada.url_imagen.startsWith("http://") ||
            portada.url_imagen.startsWith("https://")
          ) {
            portada_url = portada.url_imagen;
          } else {
            const path = portada.url_imagen.startsWith("/")
              ? portada.url_imagen.slice(1)
              : portada.url_imagen;
            portada_url = base + path;
          }
        }

        return { ...p, portada_url };
      });

      setProductos(productosConPortada);
      setProductosFiltrados(productosConPortada);

      const cats = [
        ...new Set(
          productosConPortada.map((p: any) => p.categoria).filter(Boolean)
        ),
      ];
      setCategorias(cats as string[]);

      const mezclados = [...productosConPortada].sort(
        () => Math.random() - 0.5
      );
      const cantidad = Math.min(5, Math.max(3, mezclados.length));
      setCarrusel(mezclados.slice(0, cantidad));
    } catch (e) {
      console.error("❌ Error cargando productos:", e);
    }
  };

  useEffect(() => {
    cargarProductos();
  }, []);

  const handleSelectProduct = async (producto: any) => {
    await AsyncStorage.setItem("selectedProduct", JSON.stringify(producto));
    navigation.navigate("DetallesProducto", { producto });
  };

  const filtrarCategoria = (categoria: string) => {
    const filtrados = productos.filter(
      (p) =>
        p.categoria &&
        p.categoria.toLowerCase() === categoria.toLowerCase()
    );
    setProductosFiltrados(filtrados);
  };

  const limpiarFiltro = () => setProductosFiltrados(productos);

  useEffect(() => {
    const intervalo = setInterval(() => {
      moverDerecha();
    }, 5000);

    return () => clearInterval(intervalo);
  }, [carrusel, currentIndex]);

  const moverIzquierda = () => {
    const newIndex =
      currentIndex === 0 ? carrusel.length - 1 : currentIndex - 1;
    cambiarIndex(newIndex);
  };

  const moverDerecha = () => {
    const newIndex =
      currentIndex === carrusel.length - 1 ? 0 : currentIndex + 1;
    cambiarIndex(newIndex);
  };

  const cambiarIndex = (index: number) => {
    setCurrentIndex(index);

    Animated.timing(animValue, {
      toValue: index * width,
      duration: 350,
      useNativeDriver: false,
    }).start();

    scrollRef.current?.scrollTo({
      x: index * width,
      animated: true,
    });
  };

  const renderProducto = ({ item }: any) => (
    <TouchableOpacity
      style={[
        styles.productCard,
        {
          width: width / columnCount - 20,
          backgroundColor: theme.name === "light" ? "#F0F0F0" : "#2C2C2C",
        },
      ]}
      onPress={() => handleSelectProduct(item)}
    >
      {item.portada_url ? (
        <Image
          source={{ uri: item.portada_url }}
          style={styles.productImage}
          resizeMode="contain"
        />
      ) : (
        <View style={[styles.productImage, { backgroundColor: "#ccc" }]} />
      )}

      <Text
        style={[styles.productName, { color: theme.colors.text }]}
        numberOfLines={1}
      >
        {item.nombre}
      </Text>
      <Text style={[styles.productPrice, { color: theme.colors.text }]}>
        ${Number(item.precio).toLocaleString("es-CL")}
      </Text>
    </TouchableOpacity>
  );

  return (
    <View
      style={[styles.screen, { backgroundColor: theme.colors.background }]}
    >
      <ScrollView
        style={[styles.container]}      
      >
        <View style={{ marginTop: 10, marginBottom: 20 }}>
          <MessageCarousel />
        </View>

        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
          Más vendidos
        </Text>
        
        <View style={styles.carouselWrapper}>
          <TouchableOpacity style={styles.arrowLeft} onPress={moverIzquierda}>
            <Text style={styles.arrowText}>{"<"}</Text>
          </TouchableOpacity>

          <ScrollView
            ref={scrollRef}
            horizontal
            scrollEnabled={false}
            showsHorizontalScrollIndicator={false}
            style={{ width: width }}
          >
            {carrusel.map((item) => (
              <View
                key={item.id_producto}
                style={{ width: width, alignItems: "center" }}
              >
                <TouchableOpacity
                  onPress={() => handleSelectProduct(item)}
                  style={{ alignItems: "center" }}
                >
                  {item.portada_url ? (
                    <Image
                      source={{ uri: item.portada_url }}
                      style={{
                        width: width * 0.75,
                        height: 260,
                        marginBottom: 10,
                      }}
                      resizeMode="contain"
                    />
                  ) : (
                    <View
                      style={[
                        styles.carouselImage,
                        { backgroundColor: "#ccc" },
                      ]}
                    />
                  )}

                  <Text
                    style={[
                      styles.productName,
                      { color: theme.colors.text },
                    ]}
                  >
                    {item.nombre}
                  </Text>
                  <Text
                    style={[
                      styles.productPrice,
                      { color: theme.colors.text },
                    ]}
                  >
                    ${Number(item.precio).toLocaleString("es-CL")}
                  </Text>
                </TouchableOpacity>
              </View>
            ))}
          </ScrollView>

          <TouchableOpacity style={styles.arrowRight} onPress={moverDerecha}>
            <Text style={styles.arrowText}>{">"}</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.indicadorContainer}>
          {carrusel.map((_, idx) => (
            <View
              key={idx}
              style={[
                styles.indicador,
                idx === currentIndex && styles.indicadorActivo,
              ]}
            />
          ))}
        </View>

        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
          Categorías
        </Text>

        <View style={styles.categoryContainer}>
          <TouchableOpacity
            style={[styles.categoryButton, { backgroundColor: "#4CAF50" }]}
            onPress={limpiarFiltro}
          >
            <Text style={[styles.categoryText, { color: "white" }]}>
              Ver todos
            </Text>
          </TouchableOpacity>

          {categorias.map((cat) => (
            <TouchableOpacity
              key={cat}
              style={[
                styles.categoryButton,
                { backgroundColor: theme.colors.buttonBackground },
              ]}
              onPress={() => filtrarCategoria(cat)}
            >
              <Text
                style={[
                  styles.categoryText,
                  { color: theme.colors.buttonText },
                ]}
              >
                {cat}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
          Productos
        </Text>

        <FlatList
          data={productosFiltrados}
          keyExtractor={(item) => item.id_producto.toString()}
          numColumns={columnCount}
          key={columnCount}
          renderItem={renderProducto}
          contentContainerStyle={{ paddingHorizontal: 10 }}
          scrollEnabled={false}
        />
      </ScrollView>

      {/* Burbuja flotante del asistente */}
      <ChatBubble />
    </View>
  );
}

const originalWidth = Dimensions.get("window").width;

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  container: { flex: 1 },

  sectionTitle: {
    fontSize: 22,
    fontWeight: "700",
    marginTop: 100,
    marginBottom: 10,
    marginLeft: 20,
  },

  carouselWrapper: {
    flexDirection: "row",
    alignItems: "center",
  },

  carousel: {
    width: originalWidth,
  },
  carouselItem: {
    width: originalWidth,
    alignItems: "center",
  },
  carouselImage: {
    width: originalWidth * 0.75,
    height: 260,
    marginBottom: 10,
  },

  arrowLeft: {
    position: "absolute",
    left: 10,
    zIndex: 10,
  },
  arrowRight: {
    position: "absolute",
    right: 10,
    zIndex: 10,
  },
  arrowText: {
    fontSize: 40,
    fontWeight: "bold",
    color: "#555",
  },

  indicadorContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 8,
  },
  indicador: {
    width: 8,
    height: 8,
    backgroundColor: "#999",
    borderRadius: 4,
    marginHorizontal: 4,
    opacity: 0.4,
  },
  indicadorActivo: {
    width: 12,
    height: 12,
    opacity: 1,
    backgroundColor: "#444",
  },

  categoryContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    marginBottom: 20,
  },
  categoryButton: {
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 20,
    margin: 6,
  },
  categoryText: {
    fontSize: 14,
    fontWeight: "600",
  },

  productCard: {
    borderRadius: 12,
    alignItems: "center",
    padding: 10,
    margin: 6,
  },

  productImage: {
    width: "100%",
    height: 200,
    marginBottom: 6,
  },

  productName: {
    fontSize: 14,
    fontWeight: "600",
    textAlign: "center",
  },
  productPrice: {
    fontSize: 13,
    fontWeight: "500",
  },
});