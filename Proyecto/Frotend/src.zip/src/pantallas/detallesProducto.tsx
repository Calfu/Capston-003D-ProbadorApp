import React, { useState, useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRoute, useNavigation } from "@react-navigation/native";
import { useTheme } from "../theme/ThemeContext";
import ChatBubble from "../components/ChatBubble";
import { useWindowDimensions } from "react-native";

import { API_BASE } from "../config";

export default function DetallesProducto() {
  const route: any = useRoute();
  const navigation: any = useNavigation();
  const { theme } = useTheme();
  const { producto }: any = route.params || {};

  // ⭐ Cambio único aquí:
  const { width } = useWindowDimensions();

  const [cantidad, setCantidad] = useState(0);
  const stock = Number(producto?.stock ?? 0);

  const todasImgs = useMemo(() => {
    if (!producto) return [];

    const base = API_BASE.endsWith("/") ? API_BASE : API_BASE + "/";
    const imgs: string[] = [];

    if (producto.portada_url) imgs.push(producto.portada_url);

    if (producto.imagenes && Array.isArray(producto.imagenes)) {
      producto.imagenes.forEach((img: any) => {
        if (img.es_portada === "N") {
          const path = img.url_imagen.startsWith("/")
            ? img.url_imagen.slice(1)
            : img.url_imagen;
          imgs.push(base + path);
        }
      });
    }

    return imgs;
  }, [producto]);

  if (!producto) {
    return (
      <View
        style={[
          styles.container,
          { backgroundColor: theme.colors.background },
        ]}
      >
        <Text style={[styles.text, { color: theme.colors.text }]}>
          No se encontró información del producto.
        </Text>
      </View>
    );
  }

  const mostrarAlerta = (
    titulo: string,
    mensaje: string,
    opciones: { texto: string; accion?: () => void; estilo?: "cancel" }[]
  ) => {
    if (Platform.OS === "web") {
      const confirmar = window.confirm(`${titulo}\n\n${mensaje}`);
      if (confirmar && opciones[1]?.accion) opciones[1].accion();
      return;
    }

    Alert.alert(
      titulo,
      mensaje,
      opciones.map((o) => ({
        text: o.texto,
        style: o.estilo,
        onPress: o.accion,
      }))
    );
  };

  const handleCantidadManual = (txt: string) => {
    let n = Number(txt.replace(/[^0-9]/g, ""));

    if (isNaN(n)) n = 0;
    if (n > stock) n = stock;
    if (n < 0) n = 0;

    setCantidad(n);
  };

  const handleAddCarrito = async () => {
    if (cantidad < 1) return;

    mostrarAlerta(
      "Confirmar",
      `¿Seguro que desea añadir ${cantidad} de "${producto.nombre}" al carrito?`,
      [
        { texto: "No", estilo: "cancel" },
        {
          texto: "Sí",
          accion: async () => {
            try {
              let raw = await AsyncStorage.getItem("carrito");
              let carrito = raw ? JSON.parse(raw) : [];

              const item = {
                id_producto: producto.id_producto,
                nombre: producto.nombre,
                precio: Number(producto.precio),
                cantidad,
                imagen_portada: producto.portada_url,
              };

              carrito.push(item);

              await AsyncStorage.setItem("carrito", JSON.stringify(carrito));

              mostrarAlerta("Producto añadido", "¿Desea ver su carrito?", [
                {
                  texto: "Seguir comprando",
                  estilo: "cancel",
                  accion: () => navigation.popToTop(),
                },
                {
                  texto: "Ver carrito",
                  accion: () => navigation.navigate("Carrito"),
                },
              ]);
            } catch {
              mostrarAlerta("Error", "No se pudo añadir al carrito", [
                { texto: "OK" },
              ]);
            }
          },
        },
      ]
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <ScrollView style={{ marginTop: 70 }}>
        <ScrollView
          horizontal={todasImgs.length > 1}
          pagingEnabled={todasImgs.length > 1}
          showsHorizontalScrollIndicator={false}
          style={[styles.carousel, { width }]} // ⭐ Dinámico
        >
          {todasImgs.map((uri, idx) => (
            <Image
              key={idx}
              source={{ uri }}
              style={[styles.productImage, { width }]} // ⭐ Dinámico
              resizeMode="contain"
            />
          ))}
        </ScrollView>

        <View style={styles.detailsContainer}>
          <Text style={[styles.productName, { color: theme.colors.text }]}>
            {producto.nombre}
          </Text>

          <Text style={[styles.productPrice, { color: theme.colors.text }]}>
            ${Number(producto.precio).toLocaleString("es-CL")}
          </Text>

          <View
            style={[
              styles.categoryTag,
              {
                backgroundColor:
                  theme.name === "light" ? "#E0F2FF" : "#004C99",
              },
            ]}
          >
            <Text
              style={{
                color: theme.name === "light" ? "#007ACC" : "#FFF",
              }}
            >
              {producto.categoria ?? "Sin categoría"}
            </Text>
          </View>

          <Text style={[styles.description, { color: theme.colors.text }]}>
            {producto.descripcion ??
              "Este es un producto de alta calidad, ideal para complementar tu estilo."}
          </Text>

          <Text style={[styles.stock, { color: theme.colors.text }]}>
            Stock disponible: {stock}
          </Text>

          {/* CANTIDAD */}
          <View style={styles.quantityContainer}>
            <TouchableOpacity
              onPress={() => setCantidad(Math.max(0, cantidad - 1))}
              style={[
                styles.quantityButton,
                { backgroundColor: theme.colors.buttonBackground },
              ]}
            >
              <Text
                style={[
                  styles.quantityText,
                  { color: theme.colors.buttonText },
                ]}
              >
                -
              </Text>
            </TouchableOpacity>

            <TextInput
              value={String(cantidad)}
              onChangeText={handleCantidadManual}
              keyboardType="numeric"
              style={[
                styles.quantityInput,
                {
                  color: theme.colors.text,
                  borderColor: theme.colors.text,
                },
              ]}
            />

            <TouchableOpacity
              onPress={() => setCantidad(Math.min(stock, cantidad + 1))}
              style={[
                styles.quantityButton,
                { backgroundColor: theme.colors.buttonBackground },
              ]}
            >
              <Text
                style={[
                  styles.quantityText,
                  { color: theme.colors.buttonText },
                ]}
              >
                +
              </Text>
            </TouchableOpacity>
          </View>

          {/* PROBAR PRENDA */}
          <TouchableOpacity
            style={[styles.tryButton, { backgroundColor: "#1adc71ff" }]}
            onPress={() => navigation.navigate("Probador", { producto })}
          >
            <Text style={styles.tryButtonText}>Probar Prenda</Text>
          </TouchableOpacity>

          {/* AÑADIR AL CARRITO */}
          <TouchableOpacity
            style={[
              styles.addButton,
              {
                backgroundColor:
                  cantidad >= 1 ? theme.colors.primary : "#777",
              },
            ]}
            disabled={cantidad < 1}
            onPress={handleAddCarrito}
          >
            <Text style={styles.addButtonText}>Añadir al carrito</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* BURBUJA DEL ASISTENTE */}
      <ChatBubble />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  carousel: { height: 330 },
  productImage: { height: 330 },

  detailsContainer: { padding: 20 },
  productName: { fontSize: 24, fontWeight: "700", marginTop: 10 },
  productPrice: {
    fontSize: 22,
    fontWeight: "600",
    alignSelf: "flex-end",
    marginVertical: 8,
  },

  categoryTag: {
    alignSelf: "flex-start",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    marginVertical: 10,
  },
  description: { fontSize: 16, marginVertical: 10, lineHeight: 22 },
  stock: { fontSize: 14, marginBottom: 20 },

  quantityContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginVertical: 10,
  },
  quantityButton: {
    padding: 10,
    borderRadius: 8,
    marginHorizontal: 10,
    minWidth: 40,
    alignItems: "center",
  },
  quantityText: { fontSize: 18, fontWeight: "700" },

  quantityInput: {
    minWidth: 60,
    textAlign: "center",
    paddingVertical: 6,
    borderWidth: 1,
    borderRadius: 6,
    fontSize: 18,
  },

  tryButton: {
    width: "90%", 
    alignSelf: "center",
    marginTop: 10,
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
  },
  tryButtonText: { color: "#FFF", fontSize: 16, fontWeight: "700" },

  addButton: {
    marginTop: 15,
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
  },
  addButtonText: { color: "#FFF", fontSize: 16, fontWeight: "700" },

  text: {
    fontSize: 18,
    fontWeight: "600",
    textAlign: "center",
    marginTop: 120,
  },
});