import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useTheme } from "../theme/ThemeContext";
import { useNavigation } from "@react-navigation/native";

// ICONO
import Icon from "react-native-vector-icons/Ionicons";

type CarritoItem = {
  id_producto: number;
  nombre: string;
  precio: number;
  cantidad: number;
  imagen_portada: string;
};

export default function Carrito() {
  const { theme } = useTheme();
  const navigation: any = useNavigation();

  const [productos, setProductos] = useState<CarritoItem[]>([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    const cargarCarrito = async () => {
      const raw = await AsyncStorage.getItem("carrito");
      const datos: CarritoItem[] = raw ? JSON.parse(raw) : [];
      setProductos(datos);

      const suma = datos.reduce(
        (acc: number, p: CarritoItem) => acc + p.precio * p.cantidad,
        0
      );
      setTotal(suma);
    };

    const unsub = navigation.addListener("focus", cargarCarrito);
    return unsub;
  }, [navigation]);

  const eliminarProducto = async (index: number) => {
    const nuevos = [...productos];
    nuevos.splice(index, 1);

    setProductos(nuevos);
    await AsyncStorage.setItem("carrito", JSON.stringify(nuevos));

    const suma = nuevos.reduce(
      (acc, p) => acc + p.precio * p.cantidad,
      0
    );
    setTotal(suma);
  };

  const handlePago = async () => {
    if (productos.length === 0) return;

    Alert.alert("Éxito", "Función de pago no implementada.");
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          Carrito de compras
        </Text>

        {productos.length === 0 ? (
          <Text style={[styles.emptyText, { color: theme.colors.text }]}>
            No tienes productos en tu carrito.
          </Text>
        ) : (
          <>
            <FlatList
              data={productos}
              keyExtractor={(_, index) => index.toString()}
              renderItem={({ item, index }) => (
                <View
                  style={[
                    styles.item,
                    { backgroundColor: theme.colors.cardBackground },
                  ]}
                >
                  <Image
                    source={{ uri: item.imagen_portada }}
                    style={{ width: 60, height: 60, borderRadius: 8 }}
                  />

                  <View style={{ flex: 1, marginLeft: 10 }}>
                    <Text style={[styles.itemText, { color: theme.colors.text }]}>
                      {item.nombre}
                    </Text>

                    <Text style={[styles.price, { color: theme.colors.text }]}>
                      ${ (item.precio * item.cantidad).toLocaleString("es-CL") }
                    </Text>

                    <Text style={{ color: theme.colors.text, fontSize: 13 }}>
                      Cantidad: {item.cantidad}
                    </Text>
                  </View>

                  <TouchableOpacity
                    onPress={() => eliminarProducto(index)}
                    style={styles.trashButton}
                  >
                    <Icon name="trash-outline" size={22} color="#FFF" />
                  </TouchableOpacity>
                </View>
              )}
            />

            <View style={styles.totalContainer}>
              <Text style={[styles.totalLabel, { color: theme.colors.text }]}>
                Total:
              </Text>
              <Text style={[styles.totalAmount, { color: theme.colors.text }]}>
                ${total.toLocaleString("es-CL")}
              </Text>
            </View>

            {/* ✔ RESTAURADO: BOTÓN PROCEDER AL PAGO */}
            <TouchableOpacity
              disabled={productos.length === 0}
              style={[
                styles.btnPagar,
                {
                  backgroundColor:
                    productos.length === 0
                      ? "#777"
                      : theme.colors.buttonBackground,
                },
              ]}
              onPress={handlePago}
            >
              <Text style={[styles.btnText, { color: theme.colors.buttonText }]}>
                Proceder al pago
              </Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  content: {
    flex: 1,
    paddingTop: 100,
    paddingHorizontal: 20,
  },

  title: {
    fontSize: 26,
    fontWeight: "700",
    textAlign: "center",
    marginBottom: 20,
  },

  emptyText: {
    fontSize: 16,
    textAlign: "center",
    marginTop: 50,
  },

  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 14,
    borderRadius: 8,
    marginBottom: 12,
  },

  itemText: { fontSize: 16 },
  price: { fontSize: 15, fontWeight: "600" },

  trashButton: {
    padding: 8,
    backgroundColor: "#D9534F",
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },

  totalContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
    borderTopWidth: 1,
    borderColor: "#ccc",
    paddingTop: 12,
  },

  totalLabel: { fontSize: 18, fontWeight: "700" },
  totalAmount: { fontSize: 18, fontWeight: "700" },

  btnPagar: {
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 30,
    alignItems: "center",
  },

  btnText: {
    fontSize: 16,
    fontWeight: "600",
  },
});