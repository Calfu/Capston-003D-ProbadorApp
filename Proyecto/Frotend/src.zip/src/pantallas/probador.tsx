import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { useTheme } from "../theme/ThemeContext";

import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRoute } from "@react-navigation/native";
import { API_BASE } from "../config";
import * as ImagePicker from "expo-image-picker";

export default function Probador() {
  const { theme } = useTheme();
  const route = useRoute();

  // 🔥 Recibir producto completo
  const { producto }: any = route.params || {};

  const [idUsuario, setIdUsuario] = useState<number | null>(null);
  const [userUri, setUserUri] = useState<string | null>(null);
  const [portadaProducto, setPortadaProducto] = useState<string | null>(null);
  const [resultado, setResultado] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // ============================
  // CARGAR USUARIO LOGEADO
  // ============================
  useEffect(() => {
    const loadUser = async () => {
      const raw = await AsyncStorage.getItem("user");
      if (raw) {
        const u = JSON.parse(raw);
        setIdUsuario(u.id_usuario);
      }
    };
    loadUser();
  }, []);

  // ============================
  // CARGAR PORTADA DIRECTAMENTE DESDE producto
  // ============================
  useEffect(() => {
    if (!producto || !producto.portada_url) return;

    // portada_url YA viene lista desde Inicio.tsx
    setPortadaProducto(producto.portada_url);
  }, [producto]);

  // ============================
  // ELEGIR FOTO USUARIO
  // ============================
  const pickUserPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      alert("Permiso requerido.");
      return;
    }
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });
    if (!res.canceled) {
      setUserUri(res.assets[0].uri);
    }
  };

  // ============================
  // CONSULTAR RESULTADO TRYON
  // ============================
  const probarOutfit = async () => {
    if (!producto) return;
    if (!idUsuario) return;

    setLoading(true);

    try {
      const res = await fetch(
        `${API_BASE}tryon/resultado/${idUsuario}/${producto.id_producto}`
      );
      const json = await res.json();

      if (!json.ok || !json.imagen) {
        alert("❌ No existe resultado registrado.");
        setLoading(false);
        return;
      }

      const clean = json.imagen.startsWith("/")
        ? json.imagen.slice(1)
        : json.imagen;

      const base = API_BASE.endsWith("/") ? API_BASE : API_BASE + "/";
      const fullUrl = base + clean;

      setResultado(fullUrl);
    } catch (e) {
      alert("Error al obtener resultado.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>


      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 90 }}>
        {/* FOTO USUARIO */}
        <TouchableOpacity
          style={[styles.btn, { backgroundColor: theme.colors.buttonBackground }]}
          onPress={pickUserPhoto}
        >
          <Text style={[styles.btnText, { color: theme.colors.buttonText }]}>
            Elegir foto de usuario
          </Text>
        </TouchableOpacity>

        {userUri && <Image source={{ uri: userUri }} style={styles.image} />}

        {/* PRENDA */}
        {producto ? (
          <>
            <Text
              style={{
                fontSize: 18,
                fontWeight: "700",
                marginTop: 25,
                color: theme.colors.text,
              }}
            >
              Prenda seleccionada:
            </Text>

            {portadaProducto && (
              <Image source={{ uri: portadaProducto }} style={styles.image} />
            )}
          </>
        ) : (
          <Text style={{ marginTop: 30, textAlign: "center", color: theme.colors.text }}>
            No se ha seleccionado ninguna prenda.
          </Text>
        )}

        {/* BOTÓN PROBAR */}
        <TouchableOpacity
          style={[
            styles.btn,
            { backgroundColor: producto ? "#1adc71ff" : "#777" },
          ]}
          disabled={!producto}
          onPress={probarOutfit}
        >
          <Text style={styles.btnText}>
            {producto ? "Probar Outfit" : "Seleccione un producto"}
          </Text>
        </TouchableOpacity>

        {/* LOADING */}
        {loading && <ActivityIndicator size="large" color={theme.colors.primary} />}

        {/* RESULTADO */}
        {resultado && (
          <Image
            source={{ uri: resultado }}
            style={styles.resultImage}
          />
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  btn: {
    width: "90%", 
    alignSelf: "center",
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 15,
  },
  btnText: { fontWeight: "700", fontSize: 16 },
  image: {
    width: "100%",
    height: 300,
    resizeMode: "contain",
    borderRadius: 12,
    marginTop: 15,
  },
  resultImage: {
    width: "100%",
    height: 420,
    resizeMode: "contain",
    borderRadius: 12,
    marginTop: 20,
    marginBottom: 30,
  },
});