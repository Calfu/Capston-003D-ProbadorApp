// src/pantallas/RegistroAuditoria.tsx
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useTheme } from "../theme/ThemeContext";


export default function RegistroAuditoria() {
  const { theme } = useTheme();
  const [auditorias, setAuditorias] = useState<
    { usuario: string; accion: string; tipo: string; nombre: string; fecha: string }[]
  >([]);

  // Cargar registros desde AsyncStorage
  useEffect(() => {
    (async () => {
      const data = await AsyncStorage.getItem("registroAuditoria");
      if (data) setAuditorias(JSON.parse(data));
    })();
  }, []);

  // Limpiar registros
  const limpiarRegistros = async () => {
    Alert.alert("Confirmar", "¿Deseas eliminar todos los registros?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Eliminar",
        style: "destructive",
        onPress: async () => {
          await AsyncStorage.removeItem("registroAuditoria");
          setAuditorias([]);
        },
      },
    ]);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>

      <ScrollView style={styles.content}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          Registro de Auditoría
        </Text>

        {auditorias.length === 0 ? (
          <Text style={[styles.emptyText, { color: theme.colors.text }]}>
            No hay registros de auditoría aún.
          </Text>
        ) : (
          auditorias.map((item, index) => (
            <View
              key={index}
              style={[
                styles.card,
                { backgroundColor: theme.colors.inputBackground },
              ]}
            >
              <Text style={[styles.text, { color: theme.colors.text }]}>
                <Text style={styles.bold}>Usuario:</Text> {item.usuario}
              </Text>
              <Text style={[styles.text, { color: theme.colors.text }]}>
                <Text style={styles.bold}>Acción:</Text> {item.accion} {item.tipo}
              </Text>
              <Text style={[styles.text, { color: theme.colors.text }]}>
                <Text style={styles.bold}>Nombre:</Text> {item.nombre}
              </Text>
              <Text style={[styles.date, { color: theme.colors.text }]}>
                {item.fecha}
              </Text>
            </View>
          ))
        )}

        {auditorias.length > 0 && (
          <TouchableOpacity
            style={[styles.btn, { backgroundColor: "#E53935" }]}
            onPress={limpiarRegistros}
          >
            <Text style={styles.btnText}>Borrar todo</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20, paddingTop: 90 },
  title: { fontSize: 24, fontWeight: "700", marginBottom: 20, textAlign: "center" },
  card: {
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  text: { fontSize: 16 },
  bold: { fontWeight: "700" },
  date: { fontSize: 14, marginTop: 4, opacity: 0.8 },
  btn: {
    marginTop: 20,
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  btnText: { color: "#FFF", fontWeight: "700", fontSize: 16 },
  emptyText: { textAlign: "center", marginTop: 40, fontSize: 16, opacity: 0.7 },
});