// src/pantallas/FormularioDireccion.tsx
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { useTheme } from "../theme/ThemeContext";

export default function FormularioDireccion() {
  const { theme } = useTheme();
  const navigation = useNavigation<any>();
  const route = useRoute<any>();

  const direccionExistente = route.params?.direccion || null;

  const [calle, setCalle] = useState("");
  const [numero_casa, setNumeroCasa] = useState("");
  const [ciudad, setCiudad] = useState("");
  const [region, setRegion] = useState("");
  const [pais, setPais] = useState("");
  const [codigo_postal, setCodigoPostal] = useState("");

  // ===========================
  // CARGAR DATOS EXISTENTES
  // ===========================
  useEffect(() => {
    if (direccionExistente) {
      setCalle(direccionExistente.calle || "");
      setNumeroCasa(direccionExistente.numero_casa || "");
      setCiudad(direccionExistente.ciudad || "");
      setRegion(direccionExistente.region || "");
      setPais(direccionExistente.pais || "");
      setCodigoPostal(direccionExistente.codigo_postal || "");
    }
  }, []);

  // ===========================
  // GUARDAR / VALIDAR
  // ===========================
  const handleGuardar = () => {
    const todosVacios =
      !calle &&
      !numero_casa &&
      !ciudad &&
      !region &&
      !pais &&
      !codigo_postal;

    const algunoLleno =
      calle ||
      numero_casa ||
      ciudad ||
      region ||
      pais ||
      codigo_postal;

    // Si todos vacíos → permitir volver sin guardar
    if (todosVacios) {
      navigation.goBack();
      return;
    }

    // Si un campo está lleno → TODOS deben estar llenos
    if (algunoLleno) {
      if (!calle || !numero_casa || !ciudad || !region || !pais || !codigo_postal) {
        Alert.alert("Campos incompletos", "Debes completar TODOS los campos.");
        return;
      }
    }

    // Construimos el objeto dirección
    const nuevaDireccion = {
      calle,
      numero_casa,
      ciudad,
      region,
      pais,
      codigo_postal,
    };

    // Volver a perfil.tsx con los datos
    navigation.navigate("Perfil", { direccionActualizada: nuevaDireccion });
  };

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.background },
      ]}
    >
      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          Formulario de Dirección
        </Text>

        <TextInput
          placeholder="Calle"
          value={calle}
          onChangeText={setCalle}
          placeholderTextColor={theme.colors.inputText}
          style={[
            styles.input,
            {
              backgroundColor: theme.colors.inputBackground,
              color: theme.colors.inputText,
            },
          ]}
        />

        <TextInput
          placeholder="Número"
          value={numero_casa}
          onChangeText={setNumeroCasa}
          keyboardType="numeric"
          placeholderTextColor={theme.colors.inputText}
          style={[
            styles.input,
            {
              backgroundColor: theme.colors.inputBackground,
              color: theme.colors.inputText,
            },
          ]}
        />

        <TextInput
          placeholder="Ciudad"
          value={ciudad}
          onChangeText={setCiudad}
          placeholderTextColor={theme.colors.inputText}
          style={[
            styles.input,
            {
              backgroundColor: theme.colors.inputBackground,
              color: theme.colors.inputText,
            },
          ]}
        />

        <TextInput
          placeholder="Región"
          value={region}
          onChangeText={setRegion}
          placeholderTextColor={theme.colors.inputText}
          style={[
            styles.input,
            {
              backgroundColor: theme.colors.inputBackground,
              color: theme.colors.inputText,
            },
          ]}
        />

        <TextInput
          placeholder="País"
          value={pais}
          onChangeText={setPais}
          placeholderTextColor={theme.colors.inputText}
          style={[
            styles.input,
            {
              backgroundColor: theme.colors.inputBackground,
              color: theme.colors.inputText,
            },
          ]}
        />

        <TextInput
          placeholder="Código postal"
          value={codigo_postal}
          onChangeText={setCodigoPostal}
          keyboardType="numeric"
          placeholderTextColor={theme.colors.inputText}
          style={[
            styles.input,
            {
              backgroundColor: theme.colors.inputBackground,
              color: theme.colors.inputText,
            },
          ]}
        />

        <TouchableOpacity
          style={[styles.btn, { backgroundColor: theme.colors.primary }]}
          onPress={handleGuardar}
        >
          <Text style={[styles.btnText, { color: "#FFF" }]}>
            Guardar dirección
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, padding: 20, paddingTop: 90 },
  title: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 30,
    textAlign: "center",
  },
  input: {
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
  },
  btn: {
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 10,
  },
  btnText: { fontWeight: "700", fontSize: 16 },
});