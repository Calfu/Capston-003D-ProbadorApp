// src/pantallas/FormularioEmpleado.tsx 
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import { useTheme } from "../theme/ThemeContext";
import { useRoute, useNavigation } from "@react-navigation/native";
import { API_BASE } from "../config";

export default function FormularioEmpleado() {
  const { theme } = useTheme();
  const navigation: any = useNavigation();
  const route: any = useRoute();

  const modo = route.params?.modo; // "crear" | "editar"
  const empleado = route.params?.empleado || null;

  const [nombre, setNombre] = useState("");
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [confirmarPassword, setConfirmarPassword] = useState("");

  useEffect(() => {
    if (modo === "editar" && empleado) {
      setNombre(empleado.nombre);
      setCorreo(empleado.correo);
    }
  }, []);

  // ======================================================
  // VALIDACIÓN
  // ======================================================
  const todoListo =
    nombre.trim() &&
    correo.trim() &&
    password.trim() &&
    confirmarPassword.trim();

  // ======================================================
  // CREAR EMPLEADO
  // ======================================================
  const crearEmpleado = async () => {
    if (password !== confirmarPassword) {
      Alert.alert("Error", "Las contraseñas no coinciden.");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}empleados/crear`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nombre,
          correo,
          contrasena: password,
          rol: "EMPLEADO",
          foto_perfil_url: null, // Imagen eliminada
        }),
      });

      if (!res.ok) {
        Alert.alert("Error", "No se pudo crear el empleado.");
        return;
      }

      Alert.alert("Éxito", "Empleado creado correctamente.");
      navigation.goBack();
    } catch {
      Alert.alert("Error", "Hubo un problema al crear el empleado.");
    }
  };

  // ======================================================
  // EDITAR EMPLEADO
  // ======================================================
  const editarEmpleado = async () => {
    if (password !== confirmarPassword) {
      Alert.alert("Error", "Las contraseñas no coinciden.");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}usuarios/${empleado.id_usuario}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nombre,
          correo,
          contrasena: password,
          foto_perfil_url: null, // Imagen eliminada
        }),
      });

      if (!res.ok) {
        Alert.alert("Error", "No se pudo actualizar el empleado.");
        return;
      }

      Alert.alert("Éxito", "Cambios guardados correctamente.");
      navigation.goBack();
    } catch {
      Alert.alert("Error", "No se pudo actualizar el empleado.");
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.colors.text }]}>
          {modo === "crear" ? "Añadir Empleado" : "Editar Empleado"}
        </Text>

        {/* CAMPOS */}
        <TextInput
          placeholder="Nombre completo"
          placeholderTextColor={theme.colors.inputText}
          value={nombre}
          onChangeText={setNombre}
          style={[
            styles.input,
            { backgroundColor: theme.colors.inputBackground, color: theme.colors.inputText },
          ]}
        />

        <TextInput
          placeholder="Correo electrónico"
          placeholderTextColor={theme.colors.inputText}
          value={correo}
          onChangeText={setCorreo}
          keyboardType="email-address"
          style={[
            styles.input,
            { backgroundColor: theme.colors.inputBackground, color: theme.colors.inputText },
          ]}
        />

        <TextInput
          placeholder="Contraseña"
          placeholderTextColor={theme.colors.inputText}
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          style={[
            styles.input,
            { backgroundColor: theme.colors.inputBackground, color: theme.colors.inputText },
          ]}
        />

        <TextInput
          placeholder="Confirmar contraseña"
          placeholderTextColor={theme.colors.inputText}
          value={confirmarPassword}
          onChangeText={setConfirmarPassword}
          secureTextEntry
          style={[
            styles.input,
            { backgroundColor: theme.colors.inputBackground, color: theme.colors.inputText },
          ]}
        />

        {/* BOTÓN */}
        {modo === "crear" ? (
          <TouchableOpacity
            style={[styles.btn, { backgroundColor: todoListo ? theme.colors.primary : "#777" }]}
            onPress={crearEmpleado}
            disabled={!todoListo}
          >
            <Text style={styles.btnText}>Confirmar añadir</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={[styles.btn, { backgroundColor: todoListo ? theme.colors.primary : "#777" }]}
            onPress={editarEmpleado}
            disabled={!todoListo}
          >
            <Text style={styles.btnText}>Confirmar cambios</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, padding: 20, paddingTop: 90 },
  title: { fontSize: 24, fontWeight: "700", marginBottom: 30, textAlign: "center" },

  input: {
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
  },

  btn: {
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 20,
  },

  btnText: {
    color: "#FFF",
    fontWeight: "700",
    fontSize: 16,
  },
});