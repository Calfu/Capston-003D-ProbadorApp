from sqlalchemy import (
    Column, Integer, String, Float, DateTime, ForeignKey, TIMESTAMP, CLOB, func
)
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db import Base


# =========================
# USUARIOS
# =========================
class Usuario(Base):
    __tablename__ = "USUARIOS"

    id_usuario = Column("ID_USUARIO", Integer, primary_key=True, autoincrement=True)
    nombre = Column("NOMBRE", String(100), nullable=False)
    correo = Column("CORREO", String(100), nullable=False, unique=True)
    foto_perfil_url = Column("FOTO_PERFIL_URL", String(500), nullable=True)
    fecha_nac = Column("FECHA_NAC", String(20), nullable=True)

    calle = Column("CALLE", String(150), nullable=True)
    numero_casa = Column("NUMERO_CASA", String(20), nullable=True)
    ciudad = Column("CIUDAD", String(100), nullable=True)
    region = Column("REGION", String(100), nullable=True)
    pais = Column("PAIS", String(100), nullable=True)
    codigo_postal = Column("CODIGO_POSTAL", String(20), nullable=True)

    contrasena_hash = Column("CONTRASENA_HASH", String(255), nullable=False)
    rol = Column("ROL", String(20), nullable=False, default="CLIENTE")
    fecha_creacion = Column("FECHA_CREACION", TIMESTAMP, nullable=False, server_default=func.sysdate())

    # Relaciones
    pedidos = relationship("Pedido", back_populates="usuario")
    resultados_tryon = relationship("TryOnResultado", back_populates="usuario")

# =========================
# PRODUCTOS
# =========================
class Producto(Base):
    __tablename__ = "PRODUCTOS"

    id_producto = Column("ID_PRODUCTO", Integer, primary_key=True, autoincrement=True)
    nombre = Column("NOMBRE", String(150), nullable=False)
    descripcion = Column("DESCRIPCION", CLOB, nullable=False)
    # A: categoría y género como texto
    categoria = Column("CATEGORIA", String(30), nullable=False)
    genero = Column("GENERO", String(10), nullable=False)
    precio = Column("PRECIO", Float, nullable=False)
    stock = Column("STOCK", Integer, nullable=True, default=0)
    portada = Column("PORTADA", String(255), nullable=True)  # no la usamos, pero existe en la BD
    fecha_creacion = Column("FECHA_CREACION", DateTime, default=datetime.now)

    # Relaciones
    resultados_tryon = relationship("TryOnResultado", back_populates="producto")
    imagenes = relationship("ProductoImagen", back_populates="producto", cascade="all, delete-orphan")
    tallas = relationship("ProductoTalla", back_populates="producto", cascade="all, delete-orphan")

# =========================
# MAESTROS
# =========================
class Categoria(Base):
    __tablename__ = "CATEGORIAS"
    id_categoria = Column("ID_CATEGORIA", Integer, primary_key=True, autoincrement=True)
    nombre = Column("NOMBRE", String(50), nullable=False, unique=True)

class Genero(Base):
    __tablename__ = "GENEROS"
    id_genero = Column("ID_GENERO", Integer, primary_key=True, autoincrement=True)
    nombre = Column("NOMBRE", String(50), nullable=False, unique=True)

class Talla(Base):
    __tablename__ = "TALLAS"
    id_talla = Column("ID_TALLA", Integer, primary_key=True, autoincrement=True)
    codigo = Column("CODIGO", String(10), nullable=False, unique=True)

# =========================
# RELACIONES
# =========================
class ProductoTalla(Base):
    __tablename__ = "PRODUCTO_TALLAS"

    id_producto = Column("ID_PRODUCTO", Integer, ForeignKey("PRODUCTOS.ID_PRODUCTO"), primary_key=True)
    id_talla = Column("ID_TALLA", Integer, ForeignKey("TALLAS.ID_TALLA"), primary_key=True)
    stock = Column("STOCK", Integer, nullable=False)

    producto = relationship("Producto", back_populates="tallas")
    talla = relationship("Talla")

class ProductoImagen(Base):
    __tablename__ = "PRODUCTO_IMAGENES"

    id_imagen = Column("ID_IMAGEN", Integer, primary_key=True, autoincrement=True)
    id_producto = Column(Integer, ForeignKey("PRODUCTOS.ID_PRODUCTO"), nullable=False)
    url_imagen = Column("URL_IMAGEN", String(255), nullable=False)
    es_portada = Column("ES_PORTADA", String(1), default="N")

    producto = relationship("Producto", back_populates="imagenes")

# =========================
# PEDIDOS / TRY-ON
# =========================
class Pedido(Base):
    __tablename__ = "PEDIDOS"

    id_pedido = Column("ID_PEDIDO", Integer, primary_key=True, autoincrement=True)
    id_usuario = Column("ID_USUARIO", Integer, ForeignKey("USUARIOS.ID_USUARIO"), nullable=False)
    estado = Column("ESTADO", String(30), nullable=False, default="En preparación")
    fecha_pedido = Column("FECHA_PEDIDO", TIMESTAMP, nullable=False, server_default=func.sysdate())

    usuario = relationship("Usuario", back_populates="pedidos")

class TryOnResultado(Base):
    __tablename__ = "TRYON_RESULTADOS"

    id_resultado = Column("ID_RESULTADO", Integer, primary_key=True, autoincrement=True)
    id_usuario = Column("ID_USUARIO", Integer, ForeignKey("USUARIOS.ID_USUARIO"), nullable=False)
    id_producto = Column("ID_PRODUCTO", Integer, ForeignKey("PRODUCTOS.ID_PRODUCTO"), nullable=False)
    url_imagen = Column("URL_IMAGEN", String(600), nullable=False)
    fecha_creacion = Column("FECHA_CREACION", DateTime, default=func.now())

    usuario = relationship("Usuario", back_populates="resultados_tryon", lazy="joined")
    producto = relationship("Producto", back_populates="resultados_tryon", lazy="joined")


