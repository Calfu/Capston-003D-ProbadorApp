from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv
import os
import oracledb

# Cargar variables del entorno (.env)
load_dotenv()

# 馃敼 Configuraci贸n del wallet y conexi贸n
WALLET_DIR = r"C:\Capston-003D-ProbadorApp\Proyecto-Probador\Wallet_BaseDatosProbador"
os.environ["TNS_ADMIN"] = WALLET_DIR  # Oracle usar谩 esta carpeta para el wallet

# 馃敼 Inicializar el cliente Oracle (instant client)
oracledb.init_oracle_client(
    lib_dir=r"C:\oracle\instantclient-basiclite-windows.x64-19.28.0.0.0dbru\instantclient_19_28"
)

# 馃敼 Credenciales
ORACLE_USER = os.getenv("ORACLE_USER", "ADMIN")
ORACLE_PASSWORD = os.getenv("ORACLE_PASSWORD", "Perro14361436.")
ORACLE_SERVICE = os.getenv("ORACLE_SERVICE", "basedatosprobador_tp")

# 馃敼 Construir cadena de conexi贸n
DATABASE_URL = f"oracle+oracledb://{ORACLE_USER}:{ORACLE_PASSWORD}@{ORACLE_SERVICE}"

# 馃敼 Crear engine de SQLAlchemy
engine = create_engine(DATABASE_URL, echo=False, pool_pre_ping=True)

# 馃敼 Crear sesi贸n (para transacciones)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 馃敼 Base declarativa (para modelos ORM)
Base = declarative_base()

# 馃敼 Dependencia para usar la sesi贸n en rutas
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
