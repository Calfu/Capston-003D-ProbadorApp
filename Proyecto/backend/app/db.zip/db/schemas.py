from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime, date

# =========================
# USUARIOS
# =========================
class UsuarioBase(BaseModel):
    nombre: str
    correo: EmailStr

class UsuarioCreate(UsuarioBase):
    contrasena: str
    rol: str = "CLIENTE"

class UsuarioOut(UsuarioBase):
    id_usuario: int
    rol: str
    fecha_creacion: datetime
    class Config:
        from_attributes = True

class LoginRequest(BaseModel):
    correo: str
    contrasena: str

class UsuarioDetail(BaseModel):
    id_usuario: int
    nombre: str
    correo: str
    foto_perfil_url: Optional[str]
    fecha_nac: Optional[date]

    calle: Optional[str]
    numero_casa: Optional[str]
    ciudad: Optional[str]
    region: Optional[str]
    pais: Optional[str]
    codigo_postal: Optional[str]

    rol: str
    fecha_creacion: datetime

    class Config:
        from_attributes = True

class UsuarioUpdate(BaseModel):
    nombre: Optional[str] = None
    correo: Optional[str] = None
    foto_perfil_url: Optional[str] = None
    fecha_nac: Optional[date] = None

    calle: Optional[str] = None
    numero_casa: Optional[str] = None
    ciudad: Optional[str] = None
    region: Optional[str] = None
    pais: Optional[str] = None
    codigo_postal: Optional[str] = None

# =========================
# MAESTROS
# =========================
class CategoriaOut(BaseModel):
    id_categoria: int
    nombre: str
    class Config:
        from_attributes = True

class GeneroOut(BaseModel):
    id_genero: int
    nombre: str
    class Config:
        from_attributes = True

class TallaOut(BaseModel):
    id_talla: int
    codigo: str
    class Config:
        from_attributes = True

class ProductoImagenOut(BaseModel):
    id_imagen: int
    url_imagen: str
    es_portada: str
    class Config:
        from_attributes = True

class ProductoTallaOut(BaseModel):
    id_talla: int
    talla: TallaOut    # relaciÃ³n con la tabla TALLAS
    class Config:
        from_attributes = True

# =========================
# PRODUCTOS
# =========================
class ProductoBase(BaseModel):
    nombre: str
    descripcion: str
    categoria: str        # A: texto
    genero: str           # A: texto
    precio: float
    stock: int

class ProductoOut(ProductoBase):
    id_producto: int
    fecha_creacion: Optional[datetime] = None
    imagenes: list[ProductoImagenOut] = []
    tallas: list[ProductoTallaOut] = []
    class Config:
        from_attributes = True

# =========================
# CARRITOS
# =========================
class CarritoItemIn(BaseModel):
    id_producto: int
    nombre: str
    precio_unit: float
    cantidad: int
    imagen_portada_url: Optional[str] = None

class CarritoItemOut(BaseModel):
    id_item: int
    id_carrito: int
    id_producto: int
    nombre_snapshot: str
    precio_unit_snap: float
    imagen_portada_url: Optional[str] = None
    cantidad: int

    class Config:
        from_attributes = True

class CarritoCreate(BaseModel):
    id_usuario: int
    items: list[CarritoItemIn]

class CarritoOut(BaseModel):
    id_carrito: int
    id_usuario: int
    total: float
    fecha_creacion: datetime
    estado: str
    items: list[CarritoItemOut] = []

    class Config:
        from_attributes = True