from database import engine
from sqlalchemy import text

print("🔍 Probando conexión con Oracle Cloud...")

try:
    with engine.connect() as connection:
        result = connection.execute(text("SELECT '✅ Conexión exitosa a Oracle Cloud' AS mensaje FROM dual"))
        mensaje = result.scalar()
        print(mensaje)
except Exception as e:
    print("❌ Error de conexión:", e)