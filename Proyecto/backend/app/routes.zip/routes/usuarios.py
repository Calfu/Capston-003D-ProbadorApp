from fastapi import APIRouter, Depends, HTTPException, File, UploadFile
from sqlalchemy.orm import Session
from sqlalchemy import or_, func
from hashlib import sha256
from app.db import models, schemas, database
from app.db.schemas import LoginRequest
import base64
import uuid
from pathlib import Path

router = APIRouter(prefix="/usuarios", tags=["Usuarios"])


# ============================
# 🧩 REGISTRO DE USUARIO
# ============================
@router.post("/registro", response_model=schemas.UsuarioOut)
def registrar_usuario(usuario: schemas.UsuarioCreate, db: Session = Depends(database.get_db)):
    """
    Registra un nuevo usuario en la base de datos.
    El rol por defecto es CLIENTE.
    """
    # Validar duplicado por correo
    existe = db.query(models.Usuario).filter(models.Usuario.correo == usuario.correo).first()
    if existe:
        raise HTTPException(status_code=400, detail="El correo ya está registrado.")

    nuevo = models.Usuario(
        nombre=usuario.nombre.strip(),
        correo=usuario.correo.strip().lower(),
        contrasena_hash=sha256(usuario.contrasena.strip().encode()).hexdigest(),
        rol="CLIENTE",  # rol por defecto
    )
    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)

    print(f"✅ Usuario registrado: {nuevo.nombre} ({nuevo.rol})")
    return nuevo


# ============================
# 🧩 LOGIN (por correo o nombre)
# ============================
@router.post("/login")
def login(datos: LoginRequest, db: Session = Depends(database.get_db)):
    """
    Permite iniciar sesión con correo O nombre de usuario (insensible a mayúsculas).
    """
    print("🛰️ LOGIN RECIBIDO:", datos.model_dump())

    correo_o_nombre = datos.correo.strip().lower()
    contrasena = datos.contrasena.strip()

    # Buscar por correo o nombre (sin importar mayúsculas ni espacios)
    usuario = (
        db.query(models.Usuario)
        .filter(
            or_(
                func.lower(func.trim(models.Usuario.correo)) == correo_o_nombre,
                func.lower(func.trim(models.Usuario.nombre)) == correo_o_nombre,
            )
        )
        .first()
    )

    if not usuario:
        print("❌ Usuario no encontrado.")
        raise HTTPException(status_code=401, detail="Usuario no encontrado o credenciales inválidas")

    # Verificar contraseña (hash SHA256)
    hashed = sha256(contrasena.encode()).hexdigest()
    if usuario.contrasena_hash.lower() != hashed.lower():
        print("❌ Contraseña incorrecta.")
        raise HTTPException(status_code=401, detail="Credenciales inválidas")

    print(f"✅ Login correcto: {usuario.nombre} (Rol: {usuario.rol})")

    return {
        "id_usuario": usuario.id_usuario,
        "nombre": usuario.nombre,
        "rol": usuario.rol,
        "correo": usuario.correo,
    }


# ============================
# 🧩 LISTAR USUARIOS
# ============================
@router.get("/listar", response_model=list[schemas.UsuarioOut])
def listar_usuarios(db: Session = Depends(database.get_db)):
    """
    Devuelve todos los usuarios registrados.
    """
    usuarios = db.query(models.Usuario).all()
    print(f"📋 Total usuarios encontrados: {len(usuarios)}")
    return usuarios

# ============================
# ✔ OBTENER DATOS DE USUARIO
# ============================
@router.get("/{id_usuario}", response_model=schemas.UsuarioDetail)
def obtener_usuario(id_usuario: int, db: Session = Depends(database.get_db)):
    usuario = db.query(models.Usuario).filter(models.Usuario.id_usuario == id_usuario).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    return usuario


# ============================
# ✔ ACTUALIZAR USUARIO
# ============================
@router.put("/{id_usuario}", response_model=schemas.UsuarioDetail)
def actualizar_usuario(id_usuario: int, datos: schemas.UsuarioUpdate, db: Session = Depends(database.get_db)):

    usuario = db.query(models.Usuario).filter(models.Usuario.id_usuario == id_usuario).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    from datetime import datetime, date

    for campo, valor in datos.model_dump(exclude_unset=True).items():

        if campo == "fecha_nac" and isinstance(valor, str):
            try:
                valor = datetime.strptime(valor, "%Y-%m-%d").date()
            except:
                raise HTTPException(status_code=400, detail="Formato de fecha invÃ¡lido. Use YYYY-MM-DD")

        setattr(usuario, campo, valor)
        if datos.foto_perfil_url and datos.foto_perfil_url.startswith("data:image"):
            try:
                header, b64data = datos.foto_perfil_url.split(",", 1)
                binary = base64.b64decode(b64data)

                filename = f"user_{id_usuario}_{uuid.uuid4().hex[:8]}.png"
                output_path = Path("app/storage/imagenes") / filename

                with open(output_path, "wb") as f:
                    f.write(binary)

                # guardar SOLO el nombre en la DB
                usuario.foto_perfil_url = f"/imagenes/{filename}"

            except Exception as e:
                print("Error guardando imagen:", e)
                raise HTTPException(400, "Error al procesar la imagen")
        else:
            # si recibes null o texto pequeÃ±o, lo guardas directo
            usuario.foto_perfil_url = datos.foto_perfil_url
        db.commit()
        db.refresh(usuario)
    return usuario

# ============================================================
# 📸 SUBIR FOTO TEMPORAL (CREAR EMPLEADO)
# ============================================================
@router.post("/temp/foto")
async def subir_foto_temporal(archivo: UploadFile = File(...)):
    try:
        nombre = f"temp_{int(datetime.now().timestamp())}.jpg"
        ruta = Path("app/storage/imagenes") / nombre

        # Guardar archivo
        with open(ruta, "wb") as f:
            f.write(await archivo.read())

        url_publica = f"http://localhost:8000/imagenes/{nombre}"
        return {"url": url_publica}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# 📸 SUBIR / CAMBIAR FOTO DE UN EMPLEADO
# ============================================================
@router.post("/{id_usuario}/foto")
async def actualizar_foto_usuario(
    id_usuario: int,
    archivo: UploadFile = File(...),
    db: Session = Depends(database.get_db)
):
    usuario = db.query(models.Usuario).filter(models.Usuario.id_usuario == id_usuario).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    try:
        nombre = f"user_{id_usuario}_{int(datetime.now().timestamp())}.jpg"
        ruta = Path("app/storage/imagenes") / nombre

        # Guardar archivo
        with open(ruta, "wb") as f:
            f.write(await archivo.read())

        url_publica = f"http://localhost:8000/imagenes/{nombre}"

        # Guardar en BD
        usuario.foto_perfil_url = url_publica
        db.commit()

        return {"url": url_publica}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))