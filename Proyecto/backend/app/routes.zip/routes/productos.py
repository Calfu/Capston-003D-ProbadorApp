# app/routes/productos.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional, Union
import shutil, os
from datetime import datetime
from app.db import models, schemas, database

router = APIRouter(prefix="/productos", tags=["Productos"])
UPLOAD_DIR = "app/storage/imagenes"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# =========================
# 1. Listar
# =========================
@router.get("/listar", response_model=List[schemas.ProductoOut])
def listar_productos(db: Session = Depends(database.get_db)):
    return db.query(models.Producto).all()

# =========================
# 2. Crear producto
# =========================
@router.post("/crear")
async def crear_producto(
    nombre: str = Form(...),
    descripcion: str = Form(...),
    categoria: str = Form(...),
    genero: str = Form(...),
    precio: float = Form(...),
    stock: int = Form(...),
    tallas_ids: Union[List[int], str] = Form(...),
    portada: Optional[UploadFile] = File(None),
    imagenes: Optional[List[UploadFile]] = File(None),
    db: Session = Depends(database.get_db),
):
    try:
        if isinstance(tallas_ids, str):
            tallas_ids = [int(x) for x in tallas_ids.split(",") if x.strip()]

        nuevo = models.Producto(
            nombre=nombre,
            descripcion=descripcion,
            categoria=categoria,
            genero=genero,
            precio=precio,
            stock=stock,
            fecha_creacion=datetime.now(),
        )
        db.add(nuevo)
        db.commit()
        db.refresh(nuevo)

        print("🛰️ Producto recibido:", nombre, "portada:", portada.filename if portada else None)
        print("📷 Extras:", [i.filename for i in imagenes] if imagenes else None)

        for tid in tallas_ids:
            db.add(models.ProductoTalla(
                id_producto=nuevo.id_producto,
                id_talla=int(tid),
                stock=stock
            ))

        if portada:
            clean_name = os.path.basename(portada.filename).replace(" ", "_")
            path = os.path.join(UPLOAD_DIR, f"{nuevo.id_producto}_portada_{clean_name}")
            with open(path, "wb") as f:
                shutil.copyfileobj(portada.file, f)
            db.add(models.ProductoImagen(
                id_producto=nuevo.id_producto,
                url_imagen=f"imagenes/{os.path.basename(path)}".replace("\\", "/"),
                es_portada="S"
            ))
            db.flush()

        if imagenes:
            for img in imagenes:
                clean_name = os.path.basename(img.filename).replace(" ", "_")
                path = os.path.join(UPLOAD_DIR, f"{nuevo.id_producto}_{clean_name}")
                with open(path, "wb") as f:
                    shutil.copyfileobj(img.file, f)
                db.add(models.ProductoImagen(
                    id_producto=nuevo.id_producto,
                    url_imagen=f"imagenes/{os.path.basename(path)}".replace("\\", "/"),
                    es_portada="N"
                ))
            db.flush()

        db.commit()
        return {"mensaje": "✅ Producto creado correctamente", "id_producto": nuevo.id_producto}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al crear producto: {e}")

# =========================
# 3. Editar producto
# =========================
@router.put("/editar/{id_producto}")
async def editar_producto(
    id_producto: int,
    nombre: Optional[str] = Form(None),
    descripcion: Optional[str] = Form(None),
    categoria: Optional[str] = Form(None),
    genero: Optional[str] = Form(None),
    precio: Optional[float] = Form(None),
    stock: Optional[int] = Form(None),
    tallas_ids: Optional[Union[List[int], str]] = Form(None),
    portada: Optional[UploadFile] = File(None),
    imagenes: Optional[List[UploadFile]] = File(None),
    db: Session = Depends(database.get_db),
):
    producto = db.query(models.Producto).filter_by(id_producto=id_producto).first()
    if not producto:
        raise HTTPException(status_code=404, detail="Producto no encontrado")

    try:
        if nombre: producto.nombre = nombre
        if descripcion: producto.descripcion = descripcion
        if categoria: producto.categoria = categoria
        if genero: producto.genero = genero
        if precio is not None: producto.precio = precio
        if stock is not None: producto.stock = stock

        if tallas_ids:
            if isinstance(tallas_ids, str):
                tallas_ids = [int(x) for x in tallas_ids.split(",") if x.strip()]
            db.query(models.ProductoTalla).filter_by(id_producto=id_producto).delete()
            for tid in tallas_ids:
                db.add(models.ProductoTalla(
                    id_producto=id_producto,
                    id_talla=int(tid),
                    stock=stock or 0
                ))

        if portada:
            clean_name = os.path.basename(portada.filename).replace(" ", "_")
            path = os.path.join(UPLOAD_DIR, f"{id_producto}_portada_{clean_name}")
            with open(path, "wb") as f:
                shutil.copyfileobj(portada.file, f)

            portada_db = db.query(models.ProductoImagen).filter_by(
                id_producto=id_producto, es_portada="S"
            ).first()
            if portada_db:
                portada_db.url_imagen = f"imagenes/{os.path.basename(path)}".replace("\\", "/")
            else:
                db.add(models.ProductoImagen(
                    id_producto=id_producto,
                    url_imagen=f"imagenes/{os.path.basename(path)}".replace("\\", "/"),
                    es_portada="S"
                ))
            db.flush()

        if imagenes:
            for img in imagenes:
                clean_name = os.path.basename(img.filename).replace(" ", "_")
                path = os.path.join(UPLOAD_DIR, f"{id_producto}_{clean_name}")
                with open(path, "wb") as f:
                    shutil.copyfileobj(img.file, f)
                db.add(models.ProductoImagen(
                    id_producto=id_producto,
                    url_imagen=f"imagenes/{os.path.basename(path)}".replace("\\", "/"),
                    es_portada="N"
                ))
            db.flush()

        db.commit()
        return {"mensaje": "✅ Producto actualizado correctamente"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al editar producto: {e}")

# =========================
# 4. Eliminar producto
# =========================
@router.delete("/eliminar/{id_producto}")
def eliminar_producto(id_producto: int, db: Session = Depends(database.get_db)):
    prod = db.query(models.Producto).filter_by(id_producto=id_producto).first()
    if not prod:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    try:
        db.delete(prod)
        db.commit()
        return {"mensaje": "🗑️ Producto eliminado correctamente"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al eliminar producto: {e}")

# =========================
# 5. Maestros
# =========================
@router.get("/categorias", response_model=List[schemas.CategoriaOut])
def listar_categorias(db: Session = Depends(database.get_db)):
    return db.query(models.Categoria).all()

@router.get("/generos", response_model=List[schemas.GeneroOut])
def listar_generos(db: Session = Depends(database.get_db)):
    return db.query(models.Genero).all()

@router.get("/tallas", response_model=List[schemas.TallaOut])
def listar_tallas(db: Session = Depends(database.get_db)):
    return db.query(models.Talla).all()