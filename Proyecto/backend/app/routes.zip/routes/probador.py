# app/routes/probador.py
import os
import uuid
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.db.models import TryOnResultado

router = APIRouter(prefix="/tryon", tags=["TryOn"])

# Ruta física REAL donde está tu carpeta de imágenes
BASE_IMAGES_DIR = "app/storage/imagenes"

# Subcarpeta para guardar resultados de try-on
TRYON_DIR = os.path.join(BASE_IMAGES_DIR, "tryon")
os.makedirs(TRYON_DIR, exist_ok=True)

# ============================================================
# 1️⃣ GUARDAR RESULTADO TRYON
# ============================================================
@router.post("/guardar")
async def guardar_tryon(
    id_usuario: int = Form(...),
    id_producto: int = Form(...),
    imagen: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    try:
        ext = imagen.filename.split(".")[-1].lower()
        if ext not in ["png", "jpg", "jpeg"]:
            raise HTTPException(status_code=400, detail="Formato no permitido")

        filename = f"{id_usuario}_{id_producto}_{uuid.uuid4().hex}.{ext}"
        file_path = os.path.join(TRYON_DIR, filename)

        # Guardar la imagen físicamente
        with open(file_path, "wb") as f:
            f.write(await imagen.read())

        # Ruta relativa para frontend
        url_relativa = f"imagenes/tryon/{filename}"

        # Registrar en BD
        nuevo = TryOnResultado(
            id_usuario=id_usuario,
            id_producto=id_producto,
            url_imagen=url_relativa
        )
        db.add(nuevo)
        db.commit()

        return {"ok": True, "url_imagen": url_relativa}

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================
# 2️⃣ OBTENER ÚLTIMO RESULTADO TRYON
# ============================================================
@router.get("/resultado/{id_usuario}/{id_producto}")
def obtener_tryon(id_usuario: int, id_producto: int, db: Session = Depends(get_db)):
    try:
        row = (
            db.query(TryOnResultado)
            .filter(TryOnResultado.id_usuario == id_usuario,
                    TryOnResultado.id_producto == id_producto)
            .order_by(TryOnResultado.fecha_creacion.desc())
            .first()
        )

        if not row:
            return {"ok": False, "imagen": None}

        return {"ok": True, "imagen": row.url_imagen}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================
# 3️⃣ LISTAR TODAS LAS IMÁGENES DEL USUARIO
# ============================================================
@router.get("/listar/{id_usuario}")
def listar_tryon(id_usuario: int, db: Session = Depends(get_db)):
    try:
        rows = (
            db.query(TryOnResultado)
            .filter(TryOnResultado.id_usuario == id_usuario)
            .order_by(TryOnResultado.fecha_creacion.desc())
            .all()
        )

        # Convertir a URLs completas
        imagenes = [row.url_imagen for row in rows]

        return {"ok": True, "imagenes": imagenes}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================
# 4️⃣ BORRAR TODAS LAS IMÁGENES DEL USUARIO
# ============================================================
@router.delete("/borrar/{id_usuario}")
def borrar_tryon(id_usuario: int, db: Session = Depends(get_db)):
    try:
        rows = (
            db.query(TryOnResultado)
            .filter(TryOnResultado.id_usuario == id_usuario)
            .all()
        )

        # Eliminar archivos físicos
        for row in rows:
            file_path = os.path.join(BASE_IMAGES_DIR, row.url_imagen.replace("imagenes/", ""))
            if os.path.exists(file_path):
                os.remove(file_path)

        # Eliminar BD
        db.query(TryOnResultado).filter(TryOnResultado.id_usuario == id_usuario).delete()
        db.commit()

        return {"ok": True, "deleted": True}

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))