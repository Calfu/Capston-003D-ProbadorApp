from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from hashlib import sha256
from app.db import models, schemas, database
from datetime import datetime

router = APIRouter(prefix="/empleados", tags=["Empleados"])

@router.post("/crear")
def crear_empleado(datos: schemas.UsuarioCreate, db: Session = Depends(database.get_db)):
    contrasena_hash = sha256(datos.contrasena.encode()).hexdigest()
    nuevo_empleado = models.Usuario(
        nombre=datos.nombre,
        correo=datos.correo,
        contrasena_hash=contrasena_hash,
        rol="EMPLEADO",
        fecha_creacion=datetime.now()
    )
    db.add(nuevo_empleado)
    db.commit()
    db.refresh(nuevo_empleado)
    return {"mensaje": "✅ Empleado creado correctamente", "id_empleado": nuevo_empleado.id_usuario}


@router.get("/listar")
def listar_empleados(db: Session = Depends(database.get_db)):
    empleados = db.query(models.Usuario).filter(models.Usuario.rol == "EMPLEADO").all()
    return empleados


@router.delete("/{empleado_id}")
def eliminar_empleado(empleado_id: int, db: Session = Depends(database.get_db)):
    empleado = db.query(models.Usuario).filter(models.Usuario.id_usuario == empleado_id).first()
    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    db.delete(empleado)
    db.commit()
    return {"mensaje": "Empleado eliminado correctamente"}