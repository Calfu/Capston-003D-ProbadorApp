from fastapi import APIRouter
from pydantic import BaseModel
from openai import OpenAI
import chromadb
import os
from dotenv import load_dotenv


client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

router = APIRouter()

# Inicializar ChromaDB
chroma = chromadb.Client()
collection = chroma.get_or_create_collection("probador_fashion")

class Message(BaseModel):
    message: str

@router.post("/assistant")
def assistant(msg: Message):
    # Buscar información en la base fashion
    results = collection.query(
        query_texts=[msg.message],
        n_results=3
    )

    context = ""
    if results["documents"]:
        context = "\n".join(results["documents"][0])

    prompt = f"""
Eres Vesty, el asistente oficial de ProbadorApp.
Ayudas a combinar ropa, recomendar outfits, sugerir colores y estilos.
Habla con tono juvenil y amable.

Contexto de moda:
{context}

Usuario dice:
{msg.message}

Responde de forma útil, clara y amigable.
"""

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    reply = response.choices[0].message.content
    
    return {"reply": reply}