from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import models, schemas, database

router = APIRouter(prefix="/carritos", tags=["Carritos"])

# =========================
# CREAR CARRITO + ITEMS
# =========================
@router.post("/", response_model=schemas.CarritoOut)
def crear_carrito(payload: schemas.CarritoCreate, db: Session = Depends(database.get_db)):

    # Validar usuario
    usuario = (
        db.query(models.Usuario)
        .filter(models.Usuario.id_usuario == payload.id_usuario)
        .first()
    )
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    if not payload.items:
        raise HTTPException(status_code=400, detail="El carrito está vacío")

    # Calcular total
    total = 0.0
    for it in payload.items:
        if it.cantidad <= 0:
            raise HTTPException(status_code=400, detail="La cantidad debe ser mayor a 0")
        if it.precio_unit < 0:
            raise HTTPException(status_code=400, detail="Precio inválido")
        total += it.precio_unit * it.cantidad

    # Crear carrito
    carrito = models.Carrito(
        id_usuario=payload.id_usuario,
        total=total,
        estado="ABIERTO",
    )
    db.add(carrito)
    db.flush()  # para obtener carrito.id_carrito

    # Crear items
    for it in payload.items:
        item_db = models.CarritoItem(
            id_carrito=carrito.id_carrito,
            id_producto=it.id_producto,
            nombre_snapshot=it.nombre,
            precio_unit_snap=it.precio_unit,
            imagen_portada_url=it.imagen_portada_url,
            cantidad=it.cantidad,
        )
        db.add(item_db)

    db.commit()
    db.refresh(carrito)
    return carrito

# =========================
# OBTENER CARRITO POR ID
# =========================
@router.get("/{id_carrito}", response_model=schemas.CarritoOut)
def obtener_carrito(id_carrito: int, db: Session = Depends(database.get_db)):
    carrito = (
        db.query(models.Carrito)
        .filter(models.Carrito.id_carrito == id_carrito)
        .first()
    )
    if not carrito:
        raise HTTPException(status_code=404, detail="Carrito no encontrado")
    return carrito